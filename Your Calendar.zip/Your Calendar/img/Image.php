<?php
/**
 * Image class
 *
 * This class provides basic functionality for image manipulation using the GD getLibrary or ImageMagick if available.
 * Bases on https://github.com/bedeabza/Image/blob/master/src/Bedeabza/Image.php (author Dragos Badea	<bedeabza@gmail.com> )
 */
class Image
{

    /**
     * @var array
     */
    protected $_errors = array(
            'NotExists'         => 'The file %s does not exist',
            'NotReadable'       => 'The file %s is not readable',
            'Format'            => 'Unknown image format: %s',
            'NoLib'             => 'The PHP extension GD or ImageMagick is not enabled',
            'WidthHeight'       => 'Please specify at least one of the width and height parameters',
            'CropDimExceed'     => 'The cropping dimensions must be smaller and within original ones',
            'InvalidResource'   => 'Invalid image resource provided',
            'CannotSave'        => 'Cannot save image file: %s'
    );

    /**
     * @var string
     */
    protected $_lib = null;	
    
    /**
    * @var string
    */
    protected $_fileName = null;

    /**
     * @var string
     */
    protected $_format = null;

    /**
     * @var array
     */
    protected $_acceptedFormats = array('png',  'jpeg');

    /**
     * @var resource
     */
    protected $_sourceImage = null;

    /**
     * @var resource
     */
    protected $_workingImage = null;

    /**
     * @var array
     */
    protected $_details = null;
    
    //flag that tells image is rotated or not nad need rotation
    private $_needRotation = false;
    

	
    /**
     * Renders image with error message
     */
    public static function renderError($message, $width = 300, $height = 200)
    {
        if (self::getLibrary() == 'GD'){
            $im = ImageCreateTrueColor($width, $height);

            $colorInt = hexdec('FFFFFF');

            $color = imagecolorallocate($im, 0xFF & ($colorInt >> 0x10), 0xFF & ($colorInt >> 0x8), 0xFF & $colorInt);

            imagestring($im, 4, 10, 10, $message, $color);

            self::sendHeaders();
            imagejpeg($im);
            imagedestroy($im);

        }
        else{ //ImageMagick
            $image = new Imagick();
            $draw = new ImagickDraw();
            $image->newImage($width, $height, new ImagickPixel( 'black' ));

            $draw->setFillColor('white'); /* white text */
            $draw->setFontSize(15);

            $image->annotateImage( $draw, 10, 25, 0, $message );

            $image->setImageFormat('jpg');

            self::sendHeaders();
            echo $image;
        }

        die;
    }
	
    /**
     * @param string $name
     * @param int $expires in seconds
     * @return void
     */
    public static function sendHeaders($name = '', $format = 'jpeg', $expires = 0, $lastMod = null)
    {
        if ($format)
        {
            header('Content-type: image/'.$format);
        }
        
        if ($name)
        {    
            header("Content-Disposition: inline".($name ? "; filename=".$name : ''));
        }
        
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s', ($lastMod ? $lastMod : time())) . ' GMT');
        header("Cache-Control: maxage={$expires}, no-transform"); //no transform to prevent proxy change (chrome mobile)
        if($expires)
        {
            header("Expires: " . gmdate('D, d M Y H:i:s', time()+$expires) . ' GMT');
        }
        
        header_remove('Pragma'); //remove prtagma if exists, needed for some servers

    }
    
    public static function renderFile($file_name = null, $expires = 0)
    {
        $imageData = getimagesize($file_name);

        $mime = explode('/', $imageData['mime']);
        $format = array_pop($mime); //image/jpg for example 
        
        Image::sendHeaders(basename($file_name), $format, $expires, filemtime($file_name));

        readfile($file_name);
        die;
    }
    
    
    public static function getImageDetails($file_name)
    {
        $dataEXIF = @exif_read_data( $file_name );
        $orientation = @$dataEXIF[ 'Orientation' ];
		
        $details = @getimagesize($file_name);
        
        $return = array();
        
        $return['width'] = $details[0];
        $return['height'] = $details[1];
        $return['orientation'] = null;
        $return['mime'] = $details['mime'];

        //find that image is rotated or not
        //it switches height with width for correct resiznging etc.
        if ($orientation == 6 || $orientation == 8)
        {
            $return['width'] = $details[1];
            $return['height'] = $details[0];
            $return['orientation'] = $orientation;
        }
    
        return $return;
    }
    
    
    /**
     * Which library will be used.
     *
	 * @return string
	 */
    public static function getLibrary()
    {
//        return 'GD';
//        return 'ImageMagick';
//        
        return extension_loaded('imagick') ? 'ImageMagick' : 'GD';
    }

	
    /**
     * @return int
     */
    public function getWidth()
    {
        return $this->_details['width'];
    }

    /**
     * @return int
     */
    public function getHeight()
    {
        return $this->_details['height'];
    }
	
	
	/**
     * @param string|null $fileName
     */
    public function __construct($fileName)
    {			
        $fileName = realpath($fileName); //needed for windows imagick
        
        if(!file_exists($fileName) || !is_file($fileName))
        {
            $this->_error('NotExists', $fileName);
        }

        if(!is_readable($fileName))
        {
            $this->_error('NotReadable', $fileName);
        }

        $this->_details = self::getImageDetails($fileName);
               
        if ( $this->_details['orientation'] !== null)
        {
            $this->_needRotation = true;
        }

        $mime = explode('/', $this->_details['mime']);
        $this->_format = array_pop($mime); //image/jpg for example
        
        if(!in_array($this->_format, $this->_acceptedFormats))
        {
            $this->_error('Format', $this->_format);
        }

        $this->_fileName = $fileName;

        $this->_lib = self::getLibrary();
    }
    
    /**
     * Autorotates images, use it as a last step if needed
     * Supports only two orientations
     * 
     * 
     * @return boolean That operation was made or not
     */
    public function autorotate()
    {
        if (!$this->_needRotation)
            return false;
        
        if(!$this->_sourceImage)
        {
            $this->_setSourceImage();
        }
        
        $rotatedImg = $this->_rotateImg($this->_sourceImage);
        
        if ($rotatedImg !== false)
        {
            $this->_sourceImage = $rotatedImg;
        }
                
        //reset flag
        $this->_needRotation = false;
        
        return true;
    }

	/**
	 * sharpening with transparent png gives some black pixels
	 
	 * @param int $width
	 * @param int $height
	 * @param int $mode
	 * @param boolean $sharpen sharpen image when scaled down
	 * @return boolean indicating that resizing was made or not when image is too small
	 */
	public function resize($width = null, $height = null, $mode = 'fit', $sharpen = false)
	{
            list($width, $height)   = $this->_calcDefaultDimensions($width, $height);
            $cropAfter              = false;
            $cropDimensions         = array();
            
            //original size are larger than required sizes than stop
            //if fit mode, only stop if width and height are larger than original size (not one side)
            if ( 
                ($this->getWidth() == $width && $this->getHeight() == $height) ||
                ($mode == 'fill' && ($this->getWidth() < $width || $this->getHeight() < $height)) || 
                ($mode != 'fill' && $this->getWidth() < $width && $this->getHeight() < $height )
            )
            {
                return false;
            }
		
            if(!$this->_sourceImage)
            {
                $this->_setSourceImage();
            }

            //reclaculate to preserve aspect ratio
            if($width/$height != $this->getWidth()/$this->getHeight()){
                //mark for cropping
                if($mode == 'fill'){
                    $cropAfter = true;
                    $cropDimensions = array($width, $height);
                }

                if(
                    ($width/$this->getWidth() > $height/$this->getHeight() && $mode == 'fit') ||
                    ($width/$this->getWidth() < $height/$this->getHeight() && $mode == 'fill')
                ){
                    $width = $height/$this->getHeight()*$this->getWidth();
                }else{
                    $height = $width/$this->getWidth()*$this->getHeight();
                }
            }
        
            $width = round($width);
            $height = round($height);

            //create new image
            $this->_workingImage = $this->_createImage($this->_needRotation ? $height : $width, $this->_needRotation ? $width : $height);
        
            //do not resize and sharpen when mode is fill and width or height is equal to source
            if ( !($mode == 'fill' && ($width == $this->getWidth() || $height == $this->getHeight())) ){ 
                if ($this->_lib == 'GD'){
                    //move the pixels from source to new image
//                    imagecopyresampled($this->_workingImage, $this->_sourceImage, 0, 0, 0, 0, $width, $this->_needRotation ? $width : $height, $this->getWidth(), $this->getHeight());
                    imagecopyresampled($this->_workingImage, $this->_sourceImage, 0, 0, 0, 0, $this->_needRotation ? $height : $width, $this->_needRotation ? $width : $height, $this->_needRotation ? $this->getHeight() : $this->getWidth(),$this->_needRotation ? $this->getWidth() : $this->getHeight());

                    if($sharpen && function_exists('imageconvolution')) {
                        $intSharpness = $this->_findSharp($this->getWidth(), $width);
                            $arrMatrix = array(
                            array(-1, -2, -1),
                            array(-2, $intSharpness + 12, -2),
                            array(-1, -2, -1)
                        );
                        imageconvolution($this->_workingImage, $arrMatrix, $intSharpness, 0);
                    }
                }
                else{ //ImageMagick
                    
                    //reset orientation
//                    $this->_sourceImage->setImageOrientation(Imagick::ORIENTATION_TOPLEFT); 
                    
                    $this->_workingImage->resizeImage($this->_needRotation ? $height : $width, $this->_needRotation ? $width : $height, Imagick::FILTER_LANCZOS, 1);
//                    $this->_workingImage->resizeImage($width, $height, Imagick::FILTER_LANCZOS, 1);

                    if($sharpen) {
                        $this->_workingImage->sharpenImage(2,.46); //its about 28% sharp layer in PS
                    }
                }
            }
 
            $this->_replaceAndReset($width, $height);

            if($cropAfter)
                $this->cropFromCenter($cropDimensions[0], $cropDimensions[1]);
            
            return true;
	}
        

	/**
         *  Adds watermark pattern to image 
	 */
	public function add_watermark($watermark_path)
	{            
            if(!file_exists($watermark_path) || !is_file($watermark_path))
            {
                $this->_error('NotExists', $watermark_path);
            }

            if(!is_readable($watermark_path))
            {
                $this->_error('NotReadable', $watermark_path);
            }
            
            if( !$this->_sourceImage ) //lazy prepare source image, when needed only
            {
                $this->_setSourceImage();
            }
            
            if ($this->_lib == 'GD')
            {
                $watermark_img = imagecreatefrompng($watermark_path);
                $watermark_size = imagesx($watermark_img);
            }
            else
            { //ImageMgick
                $watermark_img = new Imagick($watermark_path);
                $watermark_size = $watermark_img->getImageWidth();
            }

            //find watermark new size, full size is on image that is 2000px size
            $watermark_scaled = min($watermark_size, max(25, $watermark_size * ($this->getHeight() / 2000)));
            
            if ($this->_lib !== 'GD') //imagick
            {
                $watermark_img->thumbnailImage ($watermark_scaled, $watermark_scaled); 
            }

            if ($this->_needRotation)
            {
                $watermark_img = $this->_rotateImg($watermark_img);
            }

            $col_num = max(2, ceil(6 * ($this->getWidth() / 2000))); //max 6 rows on 2000 width, min 2 cols
            $row_num = max(2, ceil(6 * ($this->getHeight() / 2000))); //max 6 rows on 2000 height, min 2 rows

            $space_h = ($this->getWidth() - ($watermark_scaled * $col_num)) / ($col_num + 1);
            $space_v = ($this->getHeight() - ($watermark_scaled * $row_num)) / ($row_num + 1);
            
            
            if($this->_needRotation)
            {
                $t_col_num = $col_num;
                $t_row_num = $row_num;
                
                $col_num = $t_row_num;
                $row_num = $t_col_num;
                
                $t_space_h = $space_h;
                $t_space_v = $space_v;
                
                $space_h = $t_space_v;
                $space_v = $t_space_h;
            }

            for ($i = 1; $i <= $row_num; $i++) 
            {
                for ($c = 1; $c <= $col_num; $c++)
                {
                    if ($this->_lib == 'GD') 
                    {
                        imagealphablending( $this->_sourceImage, true ); //needed when source image is png with transparency
                        
                        imagecopyresampled ($this->_sourceImage, $watermark_img, 
                                $space_h * $c + $watermark_scaled * ($c -1), //add space currently ocuupied by watermark
                                $space_v * $i + $watermark_scaled * ($i -1), //add space currently ocuupied by watermark
                                0, 
                                0, 
                                $watermark_scaled, 
                                $watermark_scaled, 
                                $watermark_size, 
                                $watermark_size
                            );
                    }
                    else //imagick
                    {
                        $this->_sourceImage->compositeImage($watermark_img,
                                Imagick::COMPOSITE_OVER,
                                $space_h * $c + $watermark_scaled * ($c -1), //add space currently ocuupied by watermark);
                                $space_v * $i + $watermark_scaled * ($i -1) //add space currently ocuupied by watermark
                        );
                    }
                }
            }

            //destroy watermark images
            if ($this->_lib == 'GD') 
            {
                imagedestroy($watermark_img);
            } 
            else
            {
                $watermark_img->clear();
            }
	}

	/**
	 * @param int $x
	 * @param int $y
	 * @param int $width
	 * @param int $height
	 * @return void
	 */
	public function crop($x = 0, $y = 0, $width = null, $height = null)
	{
            if( $width > $this->getWidth() || $height > $this->getHeight())
                $this->_error('CropDimExceed');

            list($width, $height) = $this->_calcDefaultDimensions($width, $height);

            if( $x + $width > $this->getWidth() || $y + $height > $this->getHeight() )
                $this->_error('CropDimExceed');
			
            if(!$this->_sourceImage)
                $this->_setSourceImage();


            //create new image
            $this->_workingImage = $this->_createImage($this->_needRotation ? $height : $width, $this->_needRotation ? $width : $height);
            

            if($this->_lib == 'GD'){
                //move the pixels from source to new image
                imagecopyresampled($this->_workingImage, $this->_sourceImage, 0, 0,  $this->_needRotation ? $y : $x, $this->_needRotation ? $x : $y, $this->_needRotation ? $height : $width, $this->_needRotation ? $width : $height, $this->_needRotation ? $height : $width, $this->_needRotation ? $width : $height);
            }
            else
            {
                $this->_workingImage->cropImage($this->_needRotation ? $height : $width, $this->_needRotation ? $width : $height, $this->_needRotation ? $y : $x, $this->_needRotation ? $x : $y);
//                $this->_workingImage->cropImage($width, $height, $x, $y);
            }

            $this->_replaceAndReset($width, $height);
	}

    /**
     * @param int $width
     * @param int $height
     * @return void
     */
    public function cropFromCenter($width, $height)
    {
        $x = (int)(($this->getWidth() - $width) / 2);
        $y = (int)(($this->getHeight() - $height) / 2);

        $this->crop($x, $y, $width, $height);
    }


    /**
     * @param string $name
     * @param int $quality
     * @return void
     */
    public function renderSource($expires = 0, $quality = 100)
    {
        $this->autorotate(); //will rotate if neeeded
        
        self::sendHeaders('', $this->_format, $expires, null );

        $this->_execute(null, $quality);
        $this->destroy();
        die;
    }	
	
    /**
     * @param null|string $fileName
     * @param int $quality
     * @return void
     */
    public function save($fileName = null, $quality = 100)
    {			
        if(!$this->_sourceImage) //no source image, just re save 
            $this->_setSourceImage();

        $fileName = $fileName ? $fileName : $this->_fileName;

        if (!$this->_execute($fileName, $quality))
            $this->_error('CannotSave', $fileName);

        $this->_fileName = $fileName;

        $this->destroy(); //destroy image
    }	

	
    /**
     * @return void
     */
    public function destroy()
    {
        if($this->_sourceImage)
        {
            if ($this->_lib == 'GD')
            {
                imagedestroy($this->_sourceImage);
            }
            else
            { //ImageMagick
                $this->_sourceImage->clear();
            }
            $this->_sourceImage = null;
        }
    }
	
	/**
     * @param string $fileName
     * @return void
     */
    protected function _setSourceImage()
    {   
        if(!function_exists('gd_info') && !extension_loaded('imagick'))
        {
            $this->_error('NoLib');
        }


        $this->_sourceImage = $this->_createImageFromFile();
    }

	/**
	 * @param int $width
	 * @param int $height
	 * @return array
	 */
	protected function _calcDefaultDimensions($width = null, $height = null)
	{
            if(!$width && !$height)
            {
                $this->_error('WidthHeight');
            }

            //autocalculate width and height if one of them is missing
            if(!$width)
            {
                $width = $height/$this->getHeight()*$this->getWidth();
            }

            if(!$height)
            {
                $height = $width/$this->getWidth()*$this->getHeight();
            }

            return array($width, $height);
	}

	/**
	 * @return resource
	 */
	protected function _createImageFromFile()
	{
            if ($this->_lib == 'GD')
            {
                $function = 'imagecreatefrom'.$this->_format;
                return $function($this->_fileName);
            }
            else
            { //ImageMgick
                return new Imagick($this->_fileName);
            }
	}

	/**
	 * @param int $width
	 * @param int $height
	 * @return resource
	 */
	protected function _createImage($width, $height)
	{
            if( $this->_lib == 'GD')
            {
                $function = function_exists('imagecreatetruecolor') ? 'imagecreatetruecolor' : 'imagecreate';
                $image = $function($width, $height);

                //special conditions for png transparence
                if($this->_format == 'png')
                {
                    imagealphablending($image, false);
                    imagesavealpha($image, true);
                    imagefilledrectangle($image, 0, 0, $width, $height, imagecolorallocatealpha($image, 255, 255, 255, 127));
                }

                return $image;
            }
            else
            { //ImageMagick
                return $this->_sourceImage;
            }
	}

	/**
	 * @param int $width
	 * @param int $height
	 * @return void
	 */
	protected function _replaceAndReset($width, $height)
	{
            if ($this->_lib == 'GD'){
                imagedestroy($this->_sourceImage);
            }

            $this->_sourceImage = $this->_workingImage;
            $this->_details['width'] = $width;
            $this->_details['height'] = $height;
        }
	
	/* 
		sharpen images function 
	*/
	protected function _findSharp($intOrig, $intFinal) 
        {
            $intFinal = $intFinal * (750.0 / $intOrig);
            $intA     = 100; //changed from 52
            $intB     = -0.27810650887573124;
            $intC     = .00047337278106508946;
            $intRes   = $intA + $intB * $intFinal + $intC * $intFinal * $intFinal;
            return max(round($intRes), 0);
	}

	/**
	 * @throws Exception
	 * @param string $code
	 * @param array $params
	 * @return void
	 */
	protected function _error($code, $param = '')
	{
            throw new Exception(sprintf($this->_errors[$code], $param));
	}


	/**
	 * @param string $fileName
	 * @param int $quality
	 * @return void
	 */
	protected function _execute($fileName = null, $quality)
	{
            
            $quality = self::getLibrary() == 'GD' ? $quality + 2 : $quality; //to match file size
            
            if ($this->_lib == 'GD')
            {
                $function = 'image'.$this->_format;
                return $function($this->_sourceImage, $fileName, $this->_getQuality($quality));
            }
            else
            { //ImageMagick
                $this->_sourceImage->setImageCompression(Imagick::COMPRESSION_JPEG); 
                $this->_sourceImage->setImageCompressionQuality($quality);

                if (!$fileName)
                    echo $this->_sourceImage;
                else
                   return $this->_sourceImage->writeImage($fileName);
            }
	}

	/**
	 * @param int $quality
	 * @return int|null
	 */
	protected function _getQuality($quality)
	{
            switch($this->_format)
            {
                case 'gif':
                    return null;
                case 'jpeg':
                    return  $quality;//to match file size
                case 'png':
                    return (int)($quality/10 - 1);
            }

            return null;
	}
        
    /**
     * Rotates image resource depending orientation
     * 
     * @param type $imgRes
     * @return boolean
     */
    private function _rotateImg($imgRes)
    {
        if ($this->_lib == 'GD')
        {
            switch ($this->_details['orientation']) 
            {
                case 6:
                {
                    return imagerotate($imgRes, 270, 0);
                }
                case 8:
                {
                    return imagerotate($imgRes, 90, 0);
                }
            }
            
        }
        else //imagick
        {
            switch ($this->_details['orientation']) 
            {
                case 6:
                {
                    $imgRes->rotateImage("#000", 90);
                    break;
                    
                }
                case 8:
                {
                    $imgRes->rotateImage("#000", -90);
                    break;
                }
            }
            $imgRes->setImageOrientation(Imagick::ORIENTATION_TOPLEFT);   
            
            return $imgRes;
        }
        
        return false;
        
    }
}