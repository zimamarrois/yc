<?php
$isDebug = isset($_SERVER['DEVELOPMENT']) ? true : false;



//loads session class from codeigniter - faster than whole CI
define('BASEPATH', true); //to proper require codeigniter files (it checks is that const exists)


define('FCPATH', realpath (dirname(__FILE__).'/../'). '/');
define('APPPATH', FCPATH.'application'.DIRECTORY_SEPARATOR);
define('ENVIRONMENT', $isDebug ? 'DEVELOPMENT' : 'production');


if (!$isDebug){
    error_reporting(0);
    ini_set('display_errors', 0);
}

require_once(FCPATH.'system/core/Common.php'); //common function 

//load manually config file, it will be not loaded by autoloading
require_once(APPPATH.'config/yourcalendar.php'); 
//used for demo
if (file_exists(FCPATH . 'demo'))
{
    require_once(FCPATH . 'demo/demo_img_config.php');
}
get_config($config); //fills internal config storage



require_once(APPPATH.'libraries/Image_operator.php'); 
$image_operator = new Image_operator();

require_once(dirname(__FILE__) .'/Image.php'); //class for images

//loads all galleries storage from php file
//$galleries_storage = include ('..'.DIRECTORY_SEPARATOR.config_item('ps_storage_folder').DIRECTORY_SEPARATOR.'data'.DIRECTORY_SEPARATOR.'galleries.php'); 

$dir = @$_GET['dir'];
//$token = @$_GET['token'];

//PARAMETERS VALIDATION and filtering
if ( !isset($dir) || !in_array( $dir, array('temp', 'uploads') ) ){
    send_error("Wrong dir param.");
}


$width = (int)@$_GET['width']; 

if ( !in_array( $width, array_merge(range(100,200,10), array(340) )) )
{
    send_error("Wrong width param for image.");
}


if ( !isset($_GET['filename']) || empty($_GET['filename']) ){
    send_error("No filename param.");
}

$filename = removerelativepath($_GET['filename']);
$filename_path = $config['yc_storage_path'].$dir.'/'.$filename;
$browser_cache = 60*60*24*4; // How long the BROWSER cache should last (seconds, minutes, hours, days. 4 days by default)

//var_dump($filename_path);
//die;
//if (!$cache_dir)
//{
//    send_error("Cache dir not exists");
//}

if ( !file_exists($filename_path) )
{
    if (!$isDebug)
    {
        http_response_code (404);
        echo '404, not found: '.$_GET['filename'];
    }
    else
    {
        send_error('Image not exists.');
    }
    exit();
}


$is_svg = pathinfo($filename_path)['extension'] == 'svg';

$cache_file = $image_operator->image_cache_filepath($filename,$dir, $width);

//checking cache
$http_if_modified_since = isset( $_SERVER['HTTP_IF_MODIFIED_SINCE'] ) ? $_SERVER['HTTP_IF_MODIFIED_SINCE'] : '';
if($http_if_modified_since)
{
    $cache_exists = file_exists($cache_file); //used when calling for image that do not need to be resized
    //example: org image height is 700px we are want 1000px so caceh will never exists coz Image class always returns original one
    if ( $image_operator->cache_valid($cache_file, $filename_path) || !$cache_exists )
    {
        // Checking if the client is validating his cache a
        $file_mod_time = filemtime($cache_exists ? $cache_file : $filename_path);
        if (strtotime($http_if_modified_since) == $file_mod_time) //must be equal (cache file not exists but will be generated)
        {
            // Client's cache is current, so we just respond '304 Not Modified'.
            http_response_code (304);
            Image::sendHeaders(null, null, $browser_cache, $file_mod_time);  
            exit;
        }
    }
}

//simply return
if ($is_svg)
{
    header('Content-type: image/svg+xml');
    readfile($filename_path);
    exit();
}

try 
{ 
    $res_file = $image_operator->image_resized_create($filename, $dir, $width);

    //no file was created
    if ( $res_file === false )
    {
        $res_file = $filename_path; //use original image
    }

    Image::renderFile($res_file, $browser_cache);
} 
catch (Exception $e) 
{
    echo send_error($e->getMessage());
}


//removes relative path from path
function removerelativepath($file) 
{
    return preg_replace ('/\.\.?[\\\\\/]/', '' , $file);
}

function send_error($message)
{
    global $isDebug;
    if (!$isDebug)
    {
        http_response_code (500);
        echo '500, error';
    }
    else
    {
//        echo $message;
        
        Image::renderError($message, 450, 300);
    }
    exit();
}


//override log_message from Common.php
function log_message($level, $message)
{
    return;
}

