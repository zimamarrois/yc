<?php
$l['installation'] = 'instalacja';

$l['req_help'] = 'Odwiedź stronę dokumentacji aby przeczytać instrukcję instalacji:';
$l['req_header'] = 'Sprawdzanie wymagań aplikacji:';
$l['req_failed'] = 'Twój serwer nie spełnia minimalnych wymagań aplikacji.<br/>Nie możesz kontynuować instalacji.';
$l['req_php'] = 'wersja PHP minium 7.2';
$l['req_gdimagick'] = 'biblioteka GD lub Imagick';
$l['req_intl'] = 'rozszerzenie PHP intl';
$l['req_perm_file'] = 'uprawnienia zapisu do pliku';
$l['req_perm_dir'] = 'uprawnienia zapisu do katalogu';
$l['req_ie'] = 'nowoczesna przeglądarka, inna niż Internet Explorer</strong>';
$l['req_ok'] = 'OK';
$l['req_fail'] = 'BRAK';

$l['db_req'] = 'Aplikacja wymaga MySQL 5.6+ lub MariaDB 10.1+ z obsługą silnika InnoDB.';
$l['started'] = 'Poprzednia instalacja nie została ukończona poprawnie, przed rozpoczęciem wyczyść bazę danych której dane podajesz.';
$l['db_invalid_form'] = 'Wypełnij poprawnie wszystkie pola.';
$l['db_invalid_connection'] = 'Nie można połączyć się z bazą danych.';

$l['db_header'] = 'Wypełnij poniższe pola niezbędne do kontynuowania instalacji.';
$l['db_name'] = 'Nazwa bazy danych:';
$l['db_user'] = 'Użytkownik bazy danych:';
$l['db_pass'] = 'Hasło bazy danych:';
$l['db_host'] = 'Host bazy danych:';
$l['password'] = 'Utwórz hasło użytkownika <b>admin</b> aplikacji Your Calendar:';
$l['password_help'] = 'Hasło musi mieć minimalną długośc 6 znaków i zawierać przynajmniej jedną literę i cyfrę.';

$l['db_progress'] = 'Trwa tworzenie struktury bazy danych. Nie przerywaj tego procesu.';
$l['db_progress_error'] = 'Wystąpił błąd podczas tworzenia bazy danych:';

$l['finished1'] = 'Instalacja została zakończona poprawnie.';
$l['finished2'] = 'Usuń katalog <b>installer</b> i odśwież stronę aby kontynuować.';
$l['finished3'] = 'Odwiedź stronę dokumentacji i przeczytaj samouczek konfiguracji w którym poznasz wszystkie detale aplikacji: <a href="https://flexphperia.net/pl/instrukcja" target="_blank">https://flexphperia.net/pl/instrukcja</a>';

$l['connection_error'] = 'Błąd połączenia ze skryptem:';

$l['next'] = 'Dalej';