<?php
$l['installation'] = 'installation';

$l['req_help'] = 'Visit the documentation page to read the installation instructions:';
$l['req_header'] = 'Checking application requirements:';
$l['req_failed'] = 'Your server does not meet the minimum application requirements.<br/>You cannot continue installation.';
$l['req_php'] = 'PHP version 7.2 or above';
$l['req_gdimagick'] = 'GD or Imagick library';
$l['req_intl'] = 'PHP extension intl';
$l['req_perm_file'] = 'file write permissions';
$l['req_perm_dir'] = 'write permissions to the directory';
$l['req_ie'] = 'a modern browser other than Internet Explorer';
$l['req_ok'] = 'OK';
$l['req_fail'] = 'FAILED';

$l['db_req'] = 'The application requires MySQL 5.6+ or MariaDB 10.1+ with InnoDB engine support.';
$l['started'] = 'The previous installation was not completed correctly, before starting erase the database which you provide data.';
$l['db_invalid_form'] = 'Please fill all the fields correctly.';
$l['db_invalid_connection'] = 'Unable to connect to the database.';

$l['db_header'] = 'Complete the following fields required to continue the installation.';
$l['db_name'] = 'Database name:';
$l['db_user'] = 'Database user:';
$l['db_pass'] = 'Database password:';
$l['db_host'] = 'Database host:';
$l['password'] = 'Create a password for the <b>admin</b> user for the Your Calendar application:';
$l['password_help'] = 'The password must be a minimum length of 6 characters and contain at least one letter and number.';

$l['db_progress'] = 'Database structure is being created. Don\'t interrupt this process.';
$l['db_progress_error'] = 'An error occurred while creating the database:';

$l['finished1'] = 'The installation has completed successfully.';
$l['finished2'] = 'Delete the <b>installer</b> folder and refresh the page to continue.';
$l['finished3'] = 'Visit the documentation page and read the configuration tutorial in which you will learn all the details of the application: <a href="https://flexphperia.net/en/manual" target="_blank">https://flexphperia.net/en/manual</a>';



$l['connection_error'] = 'Script connection failure:';

$l['next'] = 'Next';