SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE `yc_auth_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `yc_auth_perms` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `yc_auth_perm_to_group` (
  `perm_id` int(11) UNSIGNED NOT NULL,
  `group_id` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `yc_auth_perm_to_user` (
  `perm_id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `yc_auth_users` (
  `id` int(11) UNSIGNED NOT NULL,
  `username` varchar(12) CHARACTER SET utf8 NOT NULL,
  `pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `banned` tinyint(1) DEFAULT '0',
  `last_login` datetime DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `remember_time` datetime DEFAULT NULL,
  `remember_exp` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `yc_auth_user_to_group` (
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `yc_calendar_events` (
  `id` int(10) UNSIGNED NOT NULL,
  `item_id` int(10) UNSIGNED NOT NULL,
  `event_type_id` int(10) UNSIGNED NOT NULL,
  `date` datetime NOT NULL,
  `order` int(10) UNSIGNED NOT NULL,
  `is_main` tinyint(1) NOT NULL DEFAULT '0',
  `description1` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description2` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `yc_event_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `icon` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `yc_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `item_type_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(38) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `yc_item_fields` (
  `id` int(10) UNSIGNED NOT NULL,
  `item_id` int(10) UNSIGNED NOT NULL,
  `item_type_field_id` int(10) UNSIGNED NOT NULL,
  `value` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'serialized data of field options, if any '
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `yc_item_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `order` int(10) UNSIGNED NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icons` varchar(800) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc1_label` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desc1_label_show` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `desc1_type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc2_label` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desc2_label_show` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `desc2_type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc2_disabled` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `desc_show_how` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `yc_item_type_event_types` (
  `item_type_id` int(10) UNSIGNED NOT NULL,
  `event_type_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `yc_item_type_field_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `item_type_id` int(10) UNSIGNED NOT NULL,
  `order` int(10) UNSIGNED NOT NULL,
  `type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label_show` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `position` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `allow_filtering` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `size` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `yc_settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `show_empty_rows` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `browse_month_num` tinyint(1) UNSIGNED NOT NULL,
  `disable_filtering` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `editor_month_num` tinyint(1) UNSIGNED NOT NULL,
  `editor_hide_tips` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hide_login_button` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `hide_header` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `edit_one_only` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `logo` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_version_check` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


SET FOREIGN_KEY_CHECKS=1;