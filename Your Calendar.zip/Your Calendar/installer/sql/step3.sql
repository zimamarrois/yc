SET FOREIGN_KEY_CHECKS=0;

INSERT INTO `yc_auth_groups` (`id`, `name`) VALUES
(1, 'admin'),
(2, 'notlogged');

INSERT INTO `yc_auth_perms` (`id`, `name`) VALUES
(1, 'edit_item_types'),
(2, 'add_delete_item_types'),
(3, 'edit_event_types'),
(4, 'add_delete_event_types'),
(5, 'edit_users'),
(6, 'add_delete_users'),
(7, 'edit_permissions'),
(8, 'edit_settings'),
(9, 'item_type_events_browse_id_all'),
(10, 'item_type_events_desc1_id_all'),
(11, 'item_type_events_desc2_id_all'),
(12, 'item_type_events_edit_id_all'),
(13, 'item_type_edit_id_all'),
(14, 'item_type_add_delete_id_all');


INSERT INTO `yc_auth_users` (`id`, `username`, `pass`, `banned`, `last_login`, `date_created`, `remember_time`, `remember_exp`) VALUES
(1, 'admin', '', 0, NULL, NULL, NULL, NULL);


INSERT INTO `yc_auth_user_to_group` (`user_id`, `group_id`) VALUES
(1, 1);


INSERT INTO `yc_settings` (`id`, `show_empty_rows`, `browse_month_num`, `disable_filtering`, `editor_month_num`, `editor_hide_tips`, `hide_login_button`, `hide_header`, `edit_one_only`, `logo`, `title`, `language`, `last_version_check`) VALUES
(1, 0, 1, 0, 1, 0, 0, 0, 0, 'logo.svg', 'Your Calendar', 'auto', 0);


SET FOREIGN_KEY_CHECKS=1;