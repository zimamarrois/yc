SET FOREIGN_KEY_CHECKS=0;

ALTER TABLE `yc_auth_groups`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `yc_auth_perms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `perm_name` (`name`);

ALTER TABLE `yc_auth_perm_to_group`
  ADD PRIMARY KEY (`perm_id`,`group_id`),
  ADD KEY `yc_perm_to_group_ibfk_2` (`group_id`);

ALTER TABLE `yc_auth_perm_to_user`
  ADD PRIMARY KEY (`perm_id`,`user_id`),
  ADD KEY `yc_perm_to_user_ibfk_2` (`user_id`);

ALTER TABLE `yc_auth_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `yc_users_username_unique` (`username`);

ALTER TABLE `yc_auth_user_to_group`
  ADD PRIMARY KEY (`user_id`,`group_id`),
  ADD KEY `yc_user_to_groups_ibfk_2` (`group_id`);

ALTER TABLE `yc_calendar_events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `foreign_key01` (`item_id`),
  ADD KEY `foreign_key02` (`event_type_id`),
  ADD KEY `yc_calendar_events_index02` (`date`,`order`);

ALTER TABLE `yc_event_types`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `yc_items`
  ADD PRIMARY KEY (`id`,`item_type_id`) USING BTREE,
  ADD KEY `foreign_key01` (`item_type_id`);

ALTER TABLE `yc_item_fields`
  ADD PRIMARY KEY (`id`,`item_id`) USING BTREE,
  ADD KEY `foreign_key01` (`item_id`),
  ADD KEY `foreign_key02` (`item_type_field_id`);

ALTER TABLE `yc_item_types`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `yc_item_type_event_types`
  ADD PRIMARY KEY (`item_type_id`,`event_type_id`),
  ADD KEY `foreign_key01` (`item_type_id`),
  ADD KEY `foreign_key02` (`event_type_id`);

ALTER TABLE `yc_item_type_field_types`
  ADD PRIMARY KEY (`id`,`item_type_id`) USING BTREE,
  ADD KEY `foreign_key01` (`item_type_id`);

ALTER TABLE `yc_settings`
  ADD PRIMARY KEY (`id`);



ALTER TABLE `yc_auth_groups`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `yc_auth_perms`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `yc_auth_users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `yc_calendar_events`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `yc_event_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `yc_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `yc_item_fields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `yc_item_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `yc_item_type_field_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `yc_settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;


ALTER TABLE `yc_auth_perm_to_group`
  ADD CONSTRAINT `yc_auth_perm_to_group_ibfk_1` FOREIGN KEY (`perm_id`) REFERENCES `yc_auth_perms` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `yc_auth_perm_to_group_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `yc_auth_groups` (`id`) ON DELETE CASCADE;

ALTER TABLE `yc_auth_perm_to_user`
  ADD CONSTRAINT `yc_auth_perm_to_user_ibfk_1` FOREIGN KEY (`perm_id`) REFERENCES `yc_auth_perms` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `yc_auth_perm_to_user_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `yc_auth_users` (`id`) ON DELETE CASCADE;

ALTER TABLE `yc_auth_user_to_group`
  ADD CONSTRAINT `yc_auth_user_to_group_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `yc_auth_users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `yc_auth_user_to_group_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `yc_auth_groups` (`id`) ON DELETE CASCADE;

ALTER TABLE `yc_calendar_events`
  ADD CONSTRAINT `yc_calendar_events_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `yc_items` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `yc_calendar_events_ibfk_2` FOREIGN KEY (`event_type_id`) REFERENCES `yc_event_types` (`id`) ON DELETE CASCADE;

ALTER TABLE `yc_items`
  ADD CONSTRAINT `yc_items_ibfk_1` FOREIGN KEY (`item_type_id`) REFERENCES `yc_item_types` (`id`) ON DELETE CASCADE;

ALTER TABLE `yc_item_fields`
  ADD CONSTRAINT `yc_item_fields_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `yc_items` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `yc_item_fields_ibfk_2` FOREIGN KEY (`item_type_field_id`) REFERENCES `yc_item_type_field_types` (`id`) ON DELETE CASCADE;

ALTER TABLE `yc_item_type_event_types`
  ADD CONSTRAINT `yc_item_type_event_types_ibfk_1` FOREIGN KEY (`item_type_id`) REFERENCES `yc_item_types` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `yc_item_type_event_types_ibfk_2` FOREIGN KEY (`event_type_id`) REFERENCES `yc_event_types` (`id`) ON DELETE CASCADE;

ALTER TABLE `yc_item_type_field_types`
  ADD CONSTRAINT `yc_item_type_field_types_ibfk_1` FOREIGN KEY (`item_type_id`) REFERENCES `yc_item_types` (`id`) ON DELETE CASCADE;
  
  
SET FOREIGN_KEY_CHECKS=1;