<?php 

if (!defined('YCENTRY'))
{
    die('run via main dir only');
}

require_once 'inc/functions.php';
?>
<!--
 This file is part of Your Calendar app. It requires license to use.
 Copyright (c) 2020 flexphperia.net All rights reserved.

--><!DOCTYPE html>
<html lang="en">
    <head>
        <title>Your Calendar - <?php l('installation') ?></title>
        <meta charset="utf-8">
        <meta name="google" content="notranslate">
        <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
        <meta name="author" content="flexphperia.net" />

        <link rel="stylesheet" href="installer/css/bootstrap_flatly.css" />
        <link rel="stylesheet" href="installer/css/styles.css" />
</head>
<body class="<?php echo (is_install_finished() ? 'finished' : '');  ?>">

<div class="container pt-4">
    <h3 class="text-center">Your Calendar - <?php  l('installation') ?></h3>
    
    <div class="step" >
        <p>Please select installation language:</p>
        <a href="?lang=en" class="d-block">English</a>
        <a href="?lang=pl" class="d-block">Polski</a>
    </div>
    
    <div class="step">
        <div class="alert alert-info" role="alert">
           <?php l('req_help'); ?> <a href="https://flexphperia.net/yc" target="_blank">https://flexphperia.net/yc</a>
        </div>
        
        <p><?php l('req_header') ?></p>
        
        <?php if(!requirements_passed()): ?>
            <div class="alert alert-danger" role="alert">
                <?php l('req_failed') ?>
            </div>
        <?php endif; ?>
        
        <ul>
            <li><?php l('req_php') ?>:<?php echo check_req('php'); ?></li>
            <li><?php l('req_gdimagick'); ?>:<?php echo check_req('gdimagick'); ?></li>
            <li><?php l('req_intl'); ?>:<?php echo check_req('intl'); ?></li>
            <li><?php l('req_perm_file'); ?> <strong>application/config/database.php</strong>:<?php echo check_req('database.php'); ?></li>
            <li><?php l('req_perm_dir'); ?> <strong>application/cache</strong>:<?php echo check_req('app_cache'); ?></li>
            <li><?php l('req_perm_dir'); ?> <strong>application/logs</strong>:<?php echo check_req('logs'); ?></li>
            <li><?php l('req_perm_dir'); ?> <strong>storage/cache</strong>:<?php echo check_req('storage_cache'); ?></li>
            <li><?php l('req_perm_dir'); ?> <strong>storage/sessions</strong>:<?php echo check_req('storage_sessions'); ?></li>
            <li><?php l('req_perm_dir'); ?> <strong>storage/temp</strong>:<?php echo check_req('storage_temp'); ?></li>
            <li><?php l('req_perm_dir'); ?> <strong>storage/uploads</strong>:<?php echo check_req('storage_uploads'); ?></li>
            <li><?php l('req_ie'); ?>:<?php echo check_req('ie'); ?></li>
        </ul>
        
        <?php if(requirements_passed()): ?>
            <button type="button" class="btn btn-primary float-right"><?php l('next') ?><span class="ml-2">&raquo;</span></button>
        <?php endif; ?>
    </div>
    
    <div class="step" >
        <div class="alert alert-light" role="alert">
            <?php l('db_req'); ?>
        </div>
        <?php if(is_install_started()): ?>
        <div class="alert alert-danger" role="alert">
            <?php l('started'); ?>
        </div>
        <?php endif; ?>
        
        <div class="alert alert-danger d-none" role="alert" data-notvalid >
            <?php l('db_invalid_form') ?>
        </div>
        
        <div class="alert alert-danger d-none" role="alert" data-connection >
            <?php l('db_invalid_connection') ?>
        </div>
        
        <p><?php l('db_header'); ?></p>
        <form>
          <div class="form-group">
            <label for="in"><?php l('db_name'); ?></label>
            <input type="text" class="form-control" id="in" name="db_name" value="" >
          </div>
          <div class="form-group">
            <label for="iu"><?php l('db_user'); ?></label>
            <input type="text" class="form-control" id="iu" name="db_user" value="" >
          </div>
          <div class="form-group">
            <label for="ip"><?php l('db_pass'); ?></label>
            <input type="text" class="form-control" id="ip" name="db_password" value="" >
          </div>
          <div class="form-group">
            <label for="ih"><?php l('db_host'); ?></label>
            <input type="text" class="form-control" id="ih"  name="db_host"  value="localhost">
          </div>
            
          <div class="form-group">
              <label for="ipp"><?php l('password'); ?></label>
            <input type="text" class="form-control" id="ipp" name="password" value=""  >
            <small class="form-text text-muted">
                <?php l('password_help'); ?>
                
            </small>
          </div>
            
          <div class="form-group">
            <button type="button" class="btn btn-primary float-right"><?php l('next') ?><span class="ml-2">&raquo;</span></button>
          </div>
         
        </form>
    </div>
    
    
    <div class="step">
        <p><?php l('db_progress'); ?></p>
        <div class="progress" style="height: 20px;">
          <div class="progress-bar progress-bar-striped" role="progressbar" style="width: 0%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100">0%</div>
        </div>
        
        <div class="alert alert-danger d-none mt-4" role="alert"  >
            <?php l('db_progress_error') ?>
        </div>
    </div>
    
    <div class="step text-center" data-step5>
        <h4 class="text-success mb-3"><?php l('finished1'); ?></h4>
        <p><?php l('finished2'); ?></p>
        <p><?php l('finished3'); ?></p>
        
    </div>
    
</div>
    
<div id="uiBlocker" style="display:none;">
    <div class="preloader"></div>
</div>
    
<script>
    YCInstaller ={
        lang : <?php echo json_encode($lang) ?>,
        connError : <?php echo json_encode(l('connection_error', true)) ?>
    };
</script>
    
    
<script src="installer/js/jquery-3.3.1.min.js" ></script>
<script src="installer/js/bootstrap.bundle.min.js" ></script>
<script src="installer/js/uiBlockerCtrl.js" ></script>
<script src="installer/js/scripts.js" ></script>

</body>
</html>
        
        