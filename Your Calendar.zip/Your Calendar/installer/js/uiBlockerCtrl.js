+function($){
"use strict";

window.uiBlockerCtrl = {
 
    
    $blocker : null,
    
	
    init: function(){
        this.$blocker = $('body').find('#uiBlocker');
    },
    
    block : function (){
        //disable focusing on anything
        $('body').find('*').each(function(){
            var $el = $(this),
            tabindex = $el.attr('tabindex');

            if (tabindex)
                $el.data('tabindex', tabindex);

            $el.attr('tabindex', '-1');
        });
                  
        $('body').append(uiBlockerCtrl.$blocker);
        this.$blocker.show();
    },
    
    unblock : function (){
        var self = this;
        
        //small delay for performance - after ajax response there might be some html to parse
        this.$blocker.hide();
        //restore tabindexes
        $('body').find('*').each(function(){
            var $el = $(this),
                stored = $el.data('tabindex');

            if (stored)
                $el.attr('tabindex', stored);
            else
                $el.removeAttr('tabindex');
        });

    }
    
};
}($);