$(document).ready(function() {
    
    uiBlockerCtrl.init();
    
    
    var $body = $('body');
    var $steps = $('.step');
    
    if (!YCInstaller.lang)
    {
        $steps.eq(0).show();
        return;
    }
    
    if ($body.hasClass('finished'))
    {
        $steps.eq(4).show();
        return;
    }
    
    
    //requirements
    $steps.eq(1).show();
    $steps.eq(1).find('button').click(function(){
        
        $steps.hide();
        $steps.eq(2).show();
    });
    
    
    
    var dbStepNum = 0;
    var formData = null;
    var $progress = $steps.eq(3).find('.progress-bar');
    
   
    var dbStep = function(){
        
        var progress = Math.round(100 / 3 * dbStepNum);
        
        $progress
                .width(progress + '%')
                .text(progress + '%');
        
        if (dbStepNum == 3){
            setTimeout(function(){
                $steps.hide();
                $steps.eq(4).show();
            }, 500);
            return;
        }
        
        dbStepNum++;

        
       $.ajax({
            url : '?action=db-step-'+ dbStepNum,
            dataType : 'json',
            type : 'POST',
            data: formData,
            success: function(res){
                var $alert = $steps.eq(3).find('.alert');

                if (res == 'ok')
                {
                    dbStep(); //gotonext step
                }
                else
                {
                    $alert.removeClass('d-none').append('<br/>' + res);
                }

            },
            error : function(jqXHR, textStatus, errorThrown) {
                alert(YCInstaller.connError + ' ' + textStatus);
            }
        });
        
    }
    
    
    //db form
    $steps.eq(2).find('button').click(function(){
        formData = $steps.eq(2).find('form').serialize();

        uiBlockerCtrl.block();
        
        $.ajax({
            url : '?action=form-submit',
            dataType : 'json',
            type : 'POST',
            data: formData,
            success: function(res){
                var $alertValidation = $steps.eq(2).find('.alert[data-notvalid]');
                $alertValidation.addClass('d-none');
                
                var $alertConnection = $steps.eq(2).find('.alert[data-connection]');
                $alertConnection.addClass('d-none');
                
                if (res == 'notvalid')
                {
                    $alertValidation.removeClass('d-none');
                }
                else if (res == 'notconnect')
                {
                    $alertConnection.removeClass('d-none');
                }
                else if (res == 'ok')
                {
                    $steps.hide();
                    $steps.eq(3).show();
                    dbStep();
                }
            },
            error : function(jqXHR, textStatus, errorThrown) {
                alert(YCInstaller.connError + ' ' + textStatus);
            }
        })
        .always(function() {
            uiBlockerCtrl.unblock();
        });

    });
    
    

 

    
});