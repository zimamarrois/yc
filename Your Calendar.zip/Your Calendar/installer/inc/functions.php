<?php
$db_config_file = 'application/config/database.php';


$action = @$_GET['action'];

switch ($action)
{
    case 'form-submit':
    {
        if (!validate_form())
        {
            return_json('notvalid');
        }
        
        //check connection
        if (!test_db_connection())
        {
            return_json('notconnect');
        }

        return_json('ok');
    }
    case 'db-step-1':
    {
        //we have started
        install_mark_started();
        $res = db_step(1);
        
        if ($res === true){
            return_json('ok');
        }
        
        return_json($res);
    }
    case 'db-step-2':
    {
        $res = db_step(2);
        
        if ($res === true){
            return_json('ok');
        }
        
        return_json($res);
    }
    case 'db-step-3':
    {
        $res = db_step(3);
        
        if ($res === true){
            install_mark_finished();
            return_json('ok');
        }
        
        return_json($res);  
    }
}













$lang = @$_GET['lang'];

if ($lang)
{
    if (in_array($lang, array('en', 'pl')) === false)
    {
        die('wrong language');
    }
    
    require_once('installer/languages/'.$lang.'.php');
}
else{
    require_once('installer/languages/en.php'); //load fallback without setting lang var
}
//else
//{
//    $lang = 'pl';
//}


$requirements = array(
    'php' => version_compare(PHP_VERSION, '7.2.0') >= 0,
    'gdimagick' => extension_loaded('imagick') || (extension_loaded('gd') && function_exists('gd_info')),
    'intl' => check_intl(),
    'database.php' => is_writeable('application/config/database.php'),
    'app_cache' => is_writeable('application/cache'),
    'logs' => is_writeable('application/logs'),
    'storage_cache' => is_writeable('storage/cache'),
    'storage_sessions' => is_writeable('storage/sessions'),
    'storage_temp' => is_writeable('storage/temp'),
    'storage_uploads' => is_writeable('storage/uploads'),
    'ie' => !is_ie() 
);






function l($key, $return = false)
{
    global $l;
    
    if ($return)
    {
        return $l[$key];
    }
    echo $l[$key];
}


function check_req($key)
{
    global $requirements;
    return $requirements[$key] ? '<span class="ml-1 text-success"><strong>'.l('req_ok', true).'</strong></span>' : '<span class="ml-1 text-danger"><strong>'.l('req_fail', true).'</strong></span>';
}


function requirements_passed()
{
    global $requirements;
    return array_search(false, array_values($requirements), true) === false;
}

function install_mark_started()
{
    global $db_config_file;
    
    $content = file_get_contents($db_config_file);
    $content .= '{STARTED}'; //add started flag
    
    file_put_contents($db_config_file, $content);
}

function install_mark_finished()
{
    global $db_config_file;
    
    $content = file_get_contents($db_config_file);
    $content = str_replace('{STARTED}', '', $content); //remove started flag
    $content = str_replace('{DB_HOST}', $_POST['db_host'], $content);
    $content = str_replace('{DB_USER}', $_POST['db_user'], $content);
    $content = str_replace('{DB_PASS}', $_POST['db_password'], $content);
    $content = str_replace('{DB_NAME}', $_POST['db_name'], $content);
    
    file_put_contents($db_config_file, $content);
}

function is_install_started()
{
    global $db_config_file;
    
    $content = file_get_contents($db_config_file);
    
    return strpos($content, '{STARTED}') === false ? false : true;
}


function is_install_finished()
{
    global $db_config_file;
    
    $content = file_get_contents($db_config_file);
    
    //if no two strings so we are done
    $db_host = strpos($content, '{DB_HOST}') === false ? false : true;
    $started = strpos($content, '{STARTED}') === false ? false : true;
    
    return !$db_host && !$started;
}


function is_ie()
{
    $ua = htmlentities($_SERVER['HTTP_USER_AGENT'], ENT_QUOTES, 'UTF-8');
    if (preg_match('~MSIE|Internet Explorer~i', $ua) || (strpos($ua, 'Trident/7.0') !== false && strpos($ua, 'rv:11.0') !== false)) {
           return true;
    }
    
    return false;
}


function check_intl()
{
    return class_exists('Collator', true);
}


function validate_form()
{
    $pass_r = '/^(?=.*[0-9]+.*)(?=.*[a-zA-ZáàâäãåçćéèêëęíìîïłñóòôöõśúùûüýÿæœżźÁÀÂÄÃÅÇĆÉÈÊËĘÍÌÎÏÑÓÒÔÖÕŚÚÙÛÜÝŸÆŒŻŹ]+.*)[0-9\p{L}\S]{6,}$/u';
    
    if (preg_match($pass_r, $_POST['password']) !== 1)
    {
        return false;
    }
    
    if (strlen($_POST['db_name']) < 1)
    {
        return false;
    }
    
    if (strlen($_POST['db_user']) < 1)
    {
        return false;
    }
    
    return true;
 
}



function test_db_connection()
{
    $dbname = $_POST['db_name'];
    $dbuser = $_POST['db_user'];
    $dbpass = $_POST['db_password'];
    $dbhost = $_POST['db_host'];

    $link = @mysqli_connect($dbhost, $dbuser, $dbpass);
            
    if (!$link)
    {
        return false;
    }
    
    if (!mysqli_select_db($link, $dbname))
    {
        return false;
    }

    return true;
}


function db_step($num)
{
    if (!validate_form())
    {
        die('no way to change this data');
    }
    
    
    $dbname = $_POST['db_name'];
    $dbuser = $_POST['db_user'];
    $dbpass = $_POST['db_password'];
    $dbhost = $_POST['db_host'];

    $link = @mysqli_connect($dbhost, $dbuser, $dbpass);
            
    if (!$link)
    {
        return 'cannot connect';
    }
    
    if (!mysqli_select_db($link, $dbname))
    {
        return 'cannot select db';
    }
    
    $queries = file_get_contents('installer/sql/step'.$num.'.sql');
    
    //set password with proper hash
    if ($num == 3)
    {
        $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $queries .= "UPDATE yc_auth_users SET pass='$pass' WHERE id=1;"; 
    }
    
    $res = mysqli_multi_query ($link, $queries);
    
    if (!$res)
    {
        return mysqli_error ($link);
    }
    
    //loop thru results, if dont it will be asynchronously and will be weird things happend
    do{} while(mysqli_more_results($link) && mysqli_next_result($link));
    
    return true;
}


function return_json($what)
{
    header('Content-type: application/json');
    echo json_encode($what);
    
    die;
}
