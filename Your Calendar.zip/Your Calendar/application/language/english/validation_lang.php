<?php

$lang['validation_wrong_current_password'] = 'Wrong current password';
$lang['validation_user_exists'] = 'A user with this login exists.';

$lang['validation_fill_fields'] = 'Please fill in correct fields highlighted with red color. Hover over it to see details.';
$lang['validation_required'] = 'This field is required.';
$lang['validation_min_length'] = 'Please enter more than {0} characters.';
$lang['validation_max_length'] = 'Please enter no more than {0} characters.';
$lang['validation_password'] = 'Password must be at least 6 chars long and contain digits and letters.';
$lang['validation_username'] = 'The login can contain letters, numbers and periods. Must start with a letter.';
$lang['validation_equal_to'] = 'Please enter the same value again.';
$lang['validation_min'] = 'Please enter a value greater than or equal to {0}.';
$lang['validation_max'] = 'Please enter a value less than or equal to {0}.';
$lang['validation_step'] = 'Please enter a multiple of {0}.';
