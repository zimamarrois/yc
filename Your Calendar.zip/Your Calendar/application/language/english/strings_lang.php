<?php
$lang['html_lang'] = 'en';
$lang['php_locale'] = 'en_US.UTF8'; //used for date names formats
$lang['date_format'] = 'Y-m-d';  ///php DateTime format string, see here https://www.php.net/manual/function.date.php


$lang['nav_browse'] = 'Browsing';
$lang['nav_edit'] = 'Events editing';
$lang['nav_edit_selected'] = 'Edit for the selected item';
$lang['nav_manage'] = 'Manage';
$lang['nav_items'] = 'Calendar items';
$lang['nav_item_types'] = 'Calendar item types';
$lang['nav_event_types'] = 'Event types';
$lang['nav_users'] = 'Users';
$lang['nav_groups'] = 'Permission groups';
$lang['nav_user_perms'] = 'User permissions';
$lang['nav_settings'] = 'Settings';
$lang['nav_pass'] = 'Change password';
$lang['nav_logout'] = 'Logout';
$lang['nav_login'] = 'Login';

$lang['browse_title'] = 'browsing';

$lang['edit_title'] = 'events editing';
$lang['edit_tip1'] = 'Tip: Click on a cell of the day to edit events.';
$lang['edit_tip2'] = 'Tip: Click and drag to select multiple cells. You can select several separate sections by holding down the CTRL button.';

$lang['cal_nav_header'] = 'Displayed months:';
$lang['cal_nav_next'] = 'Next month';
$lang['cal_nav_prev'] = 'Previous month';
$lang['cal_nav_select'] = 'Select...';
$lang['cal_main_event'] = 'Main';
$lang['cal_filter_all'] = 'All';
$lang['cal_filter_item_header'] = 'Filter by item type:';
$lang['cal_filter_field_header'] = 'Filter by selected field:';

$lang['edit_select_title'] = 'select item';
$lang['edit_select_header'] = 'List of calendar items';
$lang['edit_select_type'] = 'Type:';
$lang['edit_select_count'] = 'Number of items:';
$lang['edit_select_filter_label'] = 'Display items of type:';
$lang['edit_select_filter_all'] = 'All';
$lang['edit_select_search'] = 'Search by name...';

$lang['settings_title'] = 'application settings';
$lang['settings_header'] = 'Application settings';
$lang['settings_refresh_help'] = 'You must refresh the page after changing this setting for it to work.';
$lang['settings_language'] = 'Language:';
$lang['settings_language_auto'] = 'Automatic (browser settings)';
$lang['settings_section_browse_header'] = 'Browsing';
$lang['settings_hide_login_button'] = 'Hide login button';
$lang['settings_hide_login_button_help'] = 'Access to the login page will only be possible by directly entering the address in the browser:';
$lang['settings_hide_header'] = 'Hide the upper bar when not logged in';
$lang['settings_edit_one_only'] = 'Editing events leads to the selection of the item';
$lang['settings_edit_one_only_help'] = 'After enabling this option, clicking the Events editing option in the top menu will take you to the selection of the calendar item to be edited. Edit access to all items at once is still available at URL:';
$lang['settings_show_empty_rows'] = 'Display rows of calendar items that do not have events for the month';
$lang['settings_show_empty_rows_help'] = 'The calendar will show item rows with empty day cells.';
$lang['settings_disable_filtering'] = 'Disable filtering';
$lang['settings_disable_filtering_help'] = 'Disables filtering despite filtering enabled for fields in calendar item types.';
$lang['settings_section_edit_header'] = 'Editing';
$lang['settings_editor_month_num'] = 'Number of months displayed:';
$lang['settings_editor_hide_tips'] = 'Don\'t display tips about clicking on cells';
$lang['settings_section_other_header'] = 'Other';
$lang['settings_logo'] = 'Logo:';
$lang['settings_logo_help'] = 'The correct resolution of the logo file are: 170x45px for the SVG file and 340x90px for the JPG or PNG files. Files with other dimensions will appear distorted.';
$lang['settings_title_field'] = 'Title:';
$lang['settings_title_field_help'] = 'The title of the page displayed on the browser tab.';

$lang['users_title'] = 'users';
$lang['users_header'] = 'Users';
$lang['users_add'] = 'Add user...';
$lang['users_count'] = 'Number of users:';

$lang['user_edit_title'] = 'user editing';
$lang['user_edit_add'] = 'Adding new user';
$lang['user_edit_edit'] = 'Edit user:';
$lang['user_edit_login'] = 'Login:';
$lang['user_edit_login_disabled'] = 'The user login cannot be changed:';
$lang['user_edit_login_help'] = 'The login can contain letters, numbers and periods. Must start with a letter.';
$lang['user_edit_pass'] = 'Password:';
$lang['user_edit_pass_change'] = 'Change password';
$lang['user_edit_pass_help'] = 'Password must be at least 6 chars long and contain digits and letters.';

$lang['user_pass_title'] = 'change password';
$lang['user_pass_header'] = 'Change password';
$lang['user_pass_old'] = 'Current password:';
$lang['user_pass_new'] = 'New password:';
$lang['user_pass_repeat'] = 'Repeat password:';

$lang['login_title'] = 'login';
$lang['login_header'] = 'Login';
$lang['login_login'] = 'Login:';
$lang['login_pass'] = 'Password:';
$lang['login_login_button'] = 'Log in';
$lang['login_remember'] = 'Remember me';
$lang['login_wrong_pass'] = 'Invalid login or password.';

$lang['logout_title'] = 'logged out';
$lang['logout_header'] = 'You have been logged out.';
$lang['logout_login_link'] = 'Click here to log in again';

$lang['perm_groups_title'] = 'permission groups';
$lang['perm_groups_header'] = 'Permission groups';
$lang['perm_groups_add'] = 'Add group...';
$lang['perm_groups_count'] = 'Number of groups:';
$lang['perm_groups_note_editable'] = 'This group cannot be edited. Members of this group have permission to all operations.';
$lang['perm_groups_admins'] = 'Administrators';
$lang['perm_groups_notlogged'] = 'Not logged in users';
$lang['perm_groups_built'] = 'System group';

$lang['perm_group_edit_title'] = 'editing permission group';
$lang['perm_group_edit_add'] = 'Adding a permission group';
$lang['perm_group_edit_edit'] = 'Editing permission group:';
$lang['perm_group_edit_name'] = 'Name:';

$lang['perm_users_title'] = 'user permissions';
$lang['perm_users_header'] = 'User permissions';
$lang['perm_users_count'] = 'Number of users:';
$lang['perm_users_note_editable'] = 'This user\'s permissions cannot be edited. The administrator has permission to all operations.';
$lang['perm_users_built'] = 'System user';

$lang['perm_user_edit_title'] = 'editing user permissions';
$lang['perm_user_edit_edit'] = 'Editing user permissions:';
$lang['perm_user_groups'] = 'Permission groups';
$lang['perm_user_groups_help'] = 'User belonging to permission groups.';
$lang['perm_user_group_notlogged_help'] = 'Each user inherits permissions from this group.';

$lang['perm_inherited'] = 'Inherited from the group to which the user belongs.';
$lang['perm_admin'] = 'Administrative permissions';
$lang['perm_edit_item_types'] = 'Editing types of calendar items';
$lang['perm_add_delete_item_types'] = 'Adding and deleting types of calendar items';
$lang['perm_edit_event_types'] = 'Editing event types';
$lang['perm_add_delete_event_types'] = 'Adding and deleting event types';
$lang['perm_edit_users'] = 'Editing users';
$lang['perm_add_delete_users'] = 'Add and remove users';
$lang['perm_edit_permissions'] = 'Editing permissions for groups and users';
$lang['perm_edit_settings'] = 'Editing application settings';
$lang['perm_type'] = 'type:';
$lang['perm_all_types'] = 'All types';
$lang['perm_items'] = 'Calendar items';
$lang['perm_item_types'] = 'Calendar items by type';
$lang['perm_events_browse'] = 'Viewing events without descriptions';
$lang['perm_events_desc1'] = 'Viewing description no. 1 of events';
$lang['perm_events_desc2'] = 'Viewing description no. 2 of events';
$lang['perm_events_edit'] = 'Editing events';
$lang['perm_edit'] = 'Editing details (name, icon, field values)';
$lang['perm_add'] = 'Adding and deleting type items';


$lang['event_types_title'] = 'event types';
$lang['event_types_header'] = 'Event types';
$lang['event_types_add'] = 'Add event type...';
$lang['event_types_count'] = 'Number of event types:';


$lang['event_type_edit_title'] = 'event type edition';
$lang['event_type_edit_add'] = 'Adding event type';
$lang['event_type_edit_edit'] = 'Editing event type:';
$lang['event_type_edit_name'] = 'Name:';
$lang['event_type_edit_icon'] = 'Icon:';

$lang['items_title'] = 'calendar items';
$lang['items_header'] = 'Calendar items';
$lang['items_type'] = 'Type:';
$lang['items_add'] = 'Add calendar item...';
$lang['items_count'] = 'Number of items:';
$lang['items_filter_label'] = 'Show items of type:';
$lang['items_filter_all'] = 'All';
$lang['items_linking_1'] = 'You can create a direct link to show the events of the selected item according to the pattern:';
$lang['items_linking_2'] = 'YEAR/MONTH/ITEM ID';
$lang['items_linking_3'] = 'Instead of YEAR and MONTH, you can enter &quot;0&quot; to display the year and month for the current date.';

$lang['item_edit_title'] = 'edit calendar item';
$lang['item_edit_add'] = 'Adding a calendar type item:';
$lang['item_edit_edit'] = 'Editing a calendar item:';
$lang['item_edit_name'] = 'Name:';
$lang['item_edit_icon'] = 'Icon:';
$lang['item_edit_fields'] = 'Fields';
$lang['item_edit_field_type'] = 'Field type:';
$lang['item_edit_field_text'] = 'Text';
$lang['item_edit_field_link'] = 'Link';
$lang['item_edit_field_image'] = 'Image';
$lang['item_edit_field_label'] = 'Label:';
$lang['item_edit_field_value'] = 'Value:';
$lang['item_edit_field_link_value'] = 'Link:';
$lang['item_edit_field_link_text'] = 'Link text:';
$lang['item_edit_field_image_value'] = 'Image:';
$lang['item_edit_field_image_help'] = 'Allowed file format is JPG.';

$lang['item_types_title'] = 'types of calendar items';
$lang['item_types_header'] = 'Types of calendar items';
$lang['item_types_add'] = 'Add calendar item type ...';
$lang['item_types_count'] = 'Number of types:';
$lang['item_types_order_help'] = 'Move event types to set the order in which they appear in the calendar.';

$lang['item_type_edit_title'] = 'editing of calendar item type';
$lang['item_type_edit_add'] = 'Adding a calendar item type';
$lang['item_type_edit_edit'] = 'Editing the type of calendar item:';
$lang['item_type_edit_name'] = 'Name:';
$lang['item_type_edit_icons'] = 'Allowed icons:';
$lang['item_type_edit_icons_help'] = 'Icons that can be selected by editing the details of the calendar item.';
$lang['item_type_edit_events'] = 'Event types:';
$lang['item_type_edit_events_help'] = 'Only events of the selected types can be added using this type of calendar item.';
$lang['item_type_edit_events_no'] = 'First add event types in the application so that you can assign them to types of calendar items.';
$lang['item_type_edit_events_no_selected'] = 'Select at least one event type.';
$lang['item_type_edit_desc_header'] = 'Event description fields';
$lang['item_type_edit_desc_help'] = 'Display help for event description fields';
$lang['item_type_edit_desc1_label'] = 'Label for description field 1:';
$lang['item_type_edit_desc1_label_show'] = 'Show label for description field 1 before its value';
$lang['item_type_edit_desc2_label'] = 'Label for description field 2:';
$lang['item_type_edit_desc2_label_show'] = 'Show label for description field 2 before its value';
$lang['item_type_edit_desc_label_show_help'] = 'The label will only be displayed if it is not empty.';
$lang['item_type_edit_descs_help'] = 'The label that will be displayed above the field when editing events.';
$lang['item_type_edit_desc1_type'] = 'Type of description field 1:';
$lang['item_type_edit_desc2_type'] = 'Type of description field 2:';
$lang['item_type_edit_desc_type_short'] = 'Short text field (max. 60 characters)';
$lang['item_type_edit_desc_type_long'] = 'Multi-line text field';
$lang['item_type_edit_desc2_disabled'] = 'Disable description field 2 for viewing and editing events';
$lang['item_type_edit_desc_show_how'] = 'Displaying the contents of the description fields:';
$lang['item_type_edit_desc_show_separate'] = 'One below the other';
$lang['item_type_edit_desc_show_asone'] = 'Combine values as one field';
$lang['item_type_edit_desc_show_type_help'] = 'The way the content of descriptive fields will be displayed when the user has the permissions to both.';


$lang['item_type_edit_fields'] = 'Item fields';
$lang['item_type_edit_fields_help'] = 'Display help for positioning fields';
$lang['item_type_edit_fields_add'] = 'Add...';
$lang['item_type_edit_field_text'] = 'Text';
$lang['item_type_edit_field_image'] = 'Image';
$lang['item_type_edit_field_link'] = 'Link';
$lang['item_type_edit_field_type'] = 'Field type:';
$lang['item_type_edit_field_label'] = 'Label:';
$lang['item_type_edit_field_label_show'] = 'Show label';
$lang['item_type_edit_field_filtering'] = 'Allow filtering';
$lang['item_type_edit_field_filtering_help'] = 'Allow filtering items when viewing the calendar by the value of this field.';
$lang['item_type_edit_field_size'] = 'Image size:';
$lang['item_type_edit_field_size_s'] = 'Small';
$lang['item_type_edit_field_size_m'] = 'Medium';
$lang['item_type_edit_field_size_l'] = 'Large';
$lang['item_type_edit_field_position'] = 'Position';
$lang['item_type_edit_field_up'] = 'Move upę';
$lang['item_type_edit_field_down'] = 'Move down';


//MODAL field positions  
$lang['modal_fields_header'] = 'Field positions';
$lang['modal_fields_1'] = 'The field position is used to arrange the fields according to the following diagram.';
$lang['modal_fields_2'] = 'For example, when you select position B for one field and C for the other, they will be displayed side by side.';

//MODAL desc fields
$lang['modal_desc_fields_header'] = 'Event description fields';
$lang['modal_desc_fields_1'] = 'Each event can have its own description. Two description fields are available by default. You can grant different permissions to users so that they can see one description instead of the other and vice versa.';
$lang['modal_desc_fields_2'] = 'Example of settings:';
$lang['modal_desc_fields_li_1'] = 'Use description field 1 to enter the time of the event, and description field 2 for the details of the event.';
$lang['modal_desc_fields_li_2'] = 'Give users not logged in permission to see the content of description 1 (event time) but not to see description 2 (event details).';
$lang['modal_desc_fields_li_3'] = 'Give logged in users permission to view the contents of both description fields.';
$lang['modal_desc_fields_3'] = 'This setting method can be used in the calendar to mark car reservations, a conference room or similar. Not logged in people see that the item is busy in the given hours but they do not see the details. Only authorized logged-in persons can see the booking details.';


//MODAL events editor
$lang['modal_events_edit_day_header'] = 'Editing events of the day:';
$lang['modal_events_edit_days_header'] = 'Adding events to the number of days:';
$lang['modal_events_edit_none'] = 'No events.';
$lang['modal_events_edit_desc_type_default_label'] = 'Description (field no. {0}):';
$lang['modal_events_edit_main'] = 'Main event';
$lang['modal_events_edit_order'] = 'Change the order';
$lang['modal_events_edit_edit'] = 'Edit';
$lang['modal_events_edit_del'] = 'Delete';
$lang['modal_events_edit_choose'] = 'Select the event type...';
$lang['modal_events_edit_type'] = 'Event type:';
$lang['modal_events_edit_type_locked'] = 'This event type has been disabled for this item type. You cannot change the type of this event.';
$lang['modal_events_edit_add'] = 'Add an event...';
$lang['modal_events_edit_main_help'] = 'Tip: The main event is the event that will be displayed in the cell of the calendar day.';
$lang['modal_events_edit_add_help'] = 'The events created will be added to previously selected cells.';


//CONFIRM MODAL 
$lang['confirm_delete_user_header'] = 'Deleting user';
$lang['confirm_delete_user'] = 'Do you really want to delete the user?';
$lang['confirm_delete_group_header'] = 'Deleting group';
$lang['confirm_delete_group'] = 'Are you sure you want to delete the permission group?';
$lang['confirm_delete_event_type_header'] = 'Deleting event type';
$lang['confirm_delete_event_type_1'] = 'Are you sure you want to delete event type?';
$lang['confirm_delete_event_type_2'] = 'This will delete all events of this type in the calendar and delete together with events all calendar items that in their type use this type of event as the only one to choose.';
$lang['confirm_delete_item_type_header'] = 'Deleting calendar item type';
$lang['confirm_delete_item_type_1'] = 'Are you sure you want to delete the calendar item type?';
$lang['confirm_delete_item_type_2'] = 'This will delete all events of this type of items on your calendar.';
$lang['confirm_delete_item_header'] = 'Delete calendar item';
$lang['confirm_delete_item_1'] = 'Are you sure you want to delete the calendar item?';
$lang['confirm_delete_item_2'] = 'This will delete all events of this item on the calendar.';
$lang['confirm_delete_all_events_header'] = 'Deleting all events';
$lang['confirm_delete_all_events'] = 'Are you sure you want to delete all events in the selected cells?';


//icon selector and icons section names 
$lang['icon_selector_empty'] = 'Select the icons from the list to select them...';
$lang['icons_people'] = 'People';
$lang['icons_absence'] = 'Absence types';
$lang['icons_animals'] = 'Animals';
$lang['icons_arrows'] = 'Arrows';
$lang['icons_multimedia'] = 'Multimedia';
$lang['icons_numbers'] = 'Numbers';
$lang['icons_other'] = 'Other';
$lang['icons_reservation'] = 'Reservation';
$lang['icons_vehicles'] = 'Vehicles';


//UPLOADER responses
$lang['uploader_no_file'] = 'No file';
$lang['uploader_select'] = 'Choose file...';
$lang['uploader_clear'] = 'Clear';
$lang['uploader_ext_not_allowed'] = 'This type of extension is not allowed:';
$lang['uploader_error'] = 'An error occurred while uploading the file:';


//SELECTION PANEL
$lang['selection_days'] = 'Selected days:';
$lang['selection_multi_types'] = 'You have selected day cells in different types of calendar items, you cannot add events together.';
$lang['selection_add'] = 'Add events...';
$lang['selection_remove'] = 'Delete events';


//AJAX responses
$lang['admin_ajax_events_saved'] = 'Events have been saved';
$lang['admin_ajax_events_deleted'] = 'Events have been deleted';
$lang['admin_ajax_password_changed'] = 'Password has been changed';
$lang['admin_ajax_settings_saved'] = 'Settings have been saved';
$lang['admin_ajax_user_deleted'] = 'User has been removed';
$lang['admin_ajax_user_saved'] = 'User saved';
$lang['admin_ajax_group_deleted'] = 'Group has been deleted';
$lang['admin_ajax_group_saved'] = 'Group has been saved';
$lang['admin_ajax_user_perms_saved'] = 'User permissions saved';
$lang['admin_ajax_event_type_saved'] = 'Event type saved';
$lang['admin_ajax_event_type_deleted'] = 'Event type has been deleted';
$lang['admin_ajax_item_types_order'] = 'Order saved';
$lang['admin_ajax_item_type_deleted'] = 'Calendar item type has been deleted';
$lang['admin_ajax_item_type_saved'] = 'Calendar item type has been saved';
$lang['admin_ajax_item_deleted'] = 'Calendar item has been deleted';
$lang['admin_ajax_item_saved'] = 'Calendar item saved';



//AJAX ERRORS
$lang['ajax_error_forbidden'] = 'Access forbidden. Please refresh the page';
$lang['ajax_error_wrong_params'] = 'Error: Bad parameters passed';
$lang['ajax_error_call_error'] = 'Ajax request error: ';
$lang['ajax_error_saving_data'] = 'Error saving data';
$lang['ajax_error_resource_not_found'] = 'Error: Resource not found';


$lang['delete'] = 'Delete';
$lang['ok'] = 'Ok';
$lang['cancel'] = 'Cancel';
$lang['no_results'] = 'No results';


$lang['no_changes'] = 'No changes to save';
$lang['save_changes'] = 'Save changes';
$lang['save_back_changes'] = 'Save changes and back';
$lang['unsaved'] = 'There are unsaved changes. Are you sure you want to leave the page?';

$lang['version_check'] = 'A new version of the application is available.<br/><a href="https://flexphperia.net/yc" target="_blank">Click here for details</a>';


//errors
$lang['error_404'] = 'Error 404 - Page not found, check URL';
$lang['error_403'] = 'Error 403 - You do not have permission to view this page';
$lang['error_iframe'] = 'This application cannot be displayed in the frame. Click here to open in a new tab.';
$lang['old_browser'] = 'This browser is not supported. Use a modern Chrome, Firefox or Opera browser.';