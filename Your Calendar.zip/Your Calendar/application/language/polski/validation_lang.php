<?php

$lang['validation_wrong_current_password'] = 'Niepoprawne aktualne hasło.';
$lang['validation_user_exists'] = 'Użytkownik o takim loginie istnieje.';

$lang['validation_fill_fields'] = 'Wypełnij poprawnie pola oznaczone kolorem czerwonym. Najedź na pole aby zobaczyć szczegóły błędu.';
$lang['validation_required'] = 'To pole jest wymagane.';
$lang['validation_min_length'] = 'Wpisz więcej znaków niż {0}.';
$lang['validation_max_length'] = 'Wpisz nie więcej znaków niż {0}.';
$lang['validation_password'] = 'Hasło musi mieć minimum 6 znaków i musi zawierać litery oraz cyfry.';
$lang['validation_username'] = 'Login może składać się z liter, cyfr i kropek. Musi zaczynać się od litery.';
$lang['validation_equal_to'] = 'Wpisz tą samą wartość co wyżej.';
$lang['validation_min'] = 'Wpisz wartość większą lub równą {0}.';
$lang['validation_max'] = 'Wpisz wartość mniejszą lub równą {0}.';
$lang['validation_step'] = 'Wprowadź wielokrotność liczby {0}.';
