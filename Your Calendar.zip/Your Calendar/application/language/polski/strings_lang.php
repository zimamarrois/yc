<?php
$lang['html_lang'] = 'pl';
$lang['php_locale'] = 'pl_PL.UTF8'; //used for date names formats
$lang['date_format'] = 'd-m-Y \r\.';  ///php DateTime format string, see here https://www.php.net/manual/function.date.php

$lang['nav_browse'] = 'Przeglądanie';
$lang['nav_edit'] = 'Edycja wydarzeń';
$lang['nav_edit_selected'] = 'Edytuj dla wybranego elementu';
$lang['nav_manage'] = 'Zarządzanie';
$lang['nav_items'] = 'Elementy kalendarza';
$lang['nav_item_types'] = 'Typy elementów kalendarza';
$lang['nav_event_types'] = 'Typy wydarzeń';
$lang['nav_users'] = 'Użytkownicy';
$lang['nav_groups'] = 'Grupy uprawnień';
$lang['nav_user_perms'] = 'Uprawnienia użytkowników';
$lang['nav_settings'] = 'Ustawienia';
$lang['nav_pass'] = 'Zmiana hasła';
$lang['nav_logout'] = 'Wyloguj';
$lang['nav_login'] = 'Zaloguj';

$lang['browse_title'] = 'przeglądanie';

$lang['edit_title'] = 'edycja wydarzeń';
$lang['edit_tip1'] = 'Porada: Kliknij na komórce dnia aby edytowac wydarzenia.';
$lang['edit_tip2'] = 'Porada: Kliknij i przeciągnij aby zaznaczyć wiele komórek. Możesz zaznaczać kilka oddzielnych sekcji przytrzymując wcisnięty przycisk CTRL.';

$lang['cal_nav_header'] = 'Wyświetlane miesiące:';
$lang['cal_nav_next'] = 'Następny miesiąc';
$lang['cal_nav_prev'] = 'Poprzedni miesiąc';
$lang['cal_nav_select'] = 'Wybierz...';
$lang['cal_main_event'] = 'Główne';
$lang['cal_filter_all'] = 'Wszystkie';
$lang['cal_filter_item_header'] = 'Filtruj według typu elementu:';
$lang['cal_filter_field_header'] = 'Filtruj według wybranego pola:';

$lang['edit_select_title'] = 'wybierz element';
$lang['edit_select_header'] = 'Lista elementów kalendarza';
$lang['edit_select_type'] = 'Typ:';
$lang['edit_select_count'] = 'Liczba elementów:';
$lang['edit_select_filter_label'] = 'Wyświetl elementy typu:';
$lang['edit_select_filter_all'] = 'Wszystkie';
$lang['edit_select_search'] = 'Szukaj według nazwy...';

$lang['settings_title'] = 'ustawienia aplikacji';
$lang['settings_header'] = 'Ustawienia aplikacji';
$lang['settings_refresh_help'] = 'Musisz odświeżyć stronę po zmianie tego ustawienia aby zadziałało.';
$lang['settings_language'] = 'Język:';
$lang['settings_language_auto'] = 'Automatycznie (ustawienia przeglądarki)';
$lang['settings_section_browse_header'] = 'Przeglądanie';
$lang['settings_hide_login_button'] = 'Ukryj przycisk logowania';
$lang['settings_hide_login_button_help'] = 'Dostęp do strony logowania będzie możliwy tylko bezpośrednio wpisujac w przeglądarkę adres:';
$lang['settings_hide_header'] = 'Ukryj górną belkę gdy niezalogowany';
$lang['settings_edit_one_only'] = 'Edycja wydarzeń prowadzi do wyboru elementu';
$lang['settings_edit_one_only_help'] = 'Po włączeniu tej opcji kliknięcie na opcję Edycja wydarzeń w menu górnym przenosi do wyboru elementu kalendarza do edycji. Dostęp do edycji wszystkich elementów naraz jest nadal dostępny pod adresem URL:';
$lang['settings_show_empty_rows'] = 'Wyświetlaj wiersze elementów kalendarza które nie mają wydarzeń w miesiącu';
$lang['settings_show_empty_rows_help'] = 'W kalendarzu będą widoczne wiersze elementów z pustymi komórkami dni.';
$lang['settings_disable_filtering'] = 'Wyłącz filtrowanie';
$lang['settings_disable_filtering_help'] = 'Wyłącza filtrowanie pomimo włączonego filtrowania dla pól w typach elementów kalendarza.';
$lang['settings_section_edit_header'] = 'Edycja';
$lang['settings_editor_month_num'] = 'Liczba wyświetlanych miesięcy:';
$lang['settings_editor_hide_tips'] = 'Nie wyświetlaj porad odnośnie klikania w komórki';
$lang['settings_section_other_header'] = 'Pozostałe';
$lang['settings_logo'] = 'Logo:';
$lang['settings_logo_help'] = 'Prawidłowe wymiary pliku logo to: 170 x 45px dla pliku SVG i 340 x 90px dla plików JPG lub PNG. Pliki o innych wymiarach będą wyświetlane jako zniekształcone.';
$lang['settings_title_field'] = 'Tytuł:';
$lang['settings_title_field_help'] = 'Tytuł strony wyświetlany na karcie przeglądarki.';

$lang['users_title'] = 'użytkownicy';
$lang['users_header'] = 'Użytkownicy';
$lang['users_add'] = 'Dodaj użytkownika...';
$lang['users_count'] = 'Liczba użytkowników:';

$lang['user_edit_title'] = 'edycja użytkownika';
$lang['user_edit_add'] = 'Dodawanie nowego użytkownika';
$lang['user_edit_edit'] = 'Edycja użytkownika:';
$lang['user_edit_login'] = 'Login:';
$lang['user_edit_login_disabled'] = 'Nie można zmienić loginu użytkownika:';
$lang['user_edit_login_help'] = 'Login może składać się z liter, cyfr i kropek. Musi zaczynać się od litery.';
$lang['user_edit_pass'] = 'Hasło:';
$lang['user_edit_pass_change'] = 'Zmień hasło';
$lang['user_edit_pass_help'] = 'Hasło musi mieć minimalną długośc 6 znaków i zawierać przynajmniej jedną literę i cyfrę.';

$lang['user_pass_title'] = 'zmiana hasła';
$lang['user_pass_header'] = 'Zmiana hasła';
$lang['user_pass_old'] = 'Stare hasło:';
$lang['user_pass_new'] = 'Nowe hasło:';
$lang['user_pass_repeat'] = 'Powtórz hasło:';

$lang['login_title'] = 'logowanie';
$lang['login_header'] = 'Logowanie';
$lang['login_login'] = 'Login:';
$lang['login_pass'] = 'Hasło:';
$lang['login_login_button'] = 'Zaloguj';
$lang['login_remember'] = 'Zapamiętaj mnie';
$lang['login_wrong_pass'] = 'Niepoprawny login lub hasło';

$lang['logout_title'] = 'wyloguj';
$lang['logout_header'] = 'Zostałeś wylogowany.';
$lang['logout_login_link'] = 'Kliknij aby zalogować ponownie';

$lang['perm_groups_title'] = 'grupy uprawnień';
$lang['perm_groups_header'] = 'Grupy uprawnień';
$lang['perm_groups_add'] = 'Dodaj grupę...';
$lang['perm_groups_count'] = 'Liczba grup:';
$lang['perm_groups_note_editable'] = 'Tej grupy nie można edytować. Członkowie tej grupy mają uprawnienia do wszystkich operacji.';
$lang['perm_groups_admins'] = 'Administratorzy';
$lang['perm_groups_notlogged'] = 'Niezalogowani użytkownicy';
$lang['perm_groups_built'] = 'Grupa systemowa';

$lang['perm_group_edit_title'] = 'edycja grupy uprawnień';
$lang['perm_group_edit_add'] = 'Dodawanie grupy uprawnień';
$lang['perm_group_edit_edit'] = 'Edycja grupy uprawnień:';
$lang['perm_group_edit_name'] = 'Nazwa:';

$lang['perm_users_title'] = 'uprawnienia użytkowników';
$lang['perm_users_header'] = 'Uprawnienia użytkowników';
$lang['perm_users_count'] = 'Liczba użytkowników:';
$lang['perm_users_note_editable'] = 'Uprawnień tego użytkownika nie można edytować. Administrator ma uprawnienia do wszystkich operacji.';
$lang['perm_users_built'] = 'Użytkownik systemowy';

$lang['perm_user_edit_title'] = 'edycja uprawnień użytkownika';
$lang['perm_user_edit_edit'] = 'Edycja uprawnień użytkownika:';
$lang['perm_user_groups'] = 'Grupy uprawnień';
$lang['perm_user_groups_help'] = 'Przynależność użytkownika do grup uprawnień.';
$lang['perm_user_group_notlogged_help'] = 'Każdy użytkownik dziedziczy uprawnienia z tej grupy.';

$lang['perm_inherited'] = 'Dziedziczone z grupy do której należy użytkownik.';
$lang['perm_admin'] = 'Uprawienienia administracyjne';
$lang['perm_edit_item_types'] = 'Edycja typów elementów kalendarza';
$lang['perm_add_delete_item_types'] = 'Dodawanie i usuwanie typów elementów kalendarza';
$lang['perm_edit_event_types'] = 'Edycja typów wydarzeń';
$lang['perm_add_delete_event_types'] = 'Dodawanie i usuwanie typów wydarzeń';
$lang['perm_edit_users'] = 'Edycja użytkowników';
$lang['perm_add_delete_users'] = 'Dodawanie i usuwanie użytkowników';
$lang['perm_edit_permissions'] = 'Edycja uprawnień grup i użytkowników';
$lang['perm_edit_settings'] = 'Edycja ustawień aplikacji';
$lang['perm_type'] = 'typ:';
$lang['perm_all_types'] = 'Wszystkie typy';
$lang['perm_items'] = 'Elementy kalendarza';
//$lang['perm_browse_items_help'] = 'Zezwalaj na przeglądanie wydarzeń dla wybranych elementów kalendarza.';
$lang['perm_item_types'] = 'Elementy kalendarza według ich typów';
$lang['perm_events_browse'] = 'Przeglądanie wydarzeń bez opisów';
$lang['perm_events_desc1'] = 'Przeglądanie opisu nr 1 wydarzeń';
$lang['perm_events_desc2'] = 'Przeglądanie opisu nr 2 wydarzeń';
$lang['perm_events_edit'] = 'Edycja wydarzeń';
$lang['perm_edit'] = 'Edycja szczegółów (nazwa, ikona, wartości pól)';
$lang['perm_add'] = 'Dodawanie i usuwanie elementów typu';


$lang['event_types_title'] = 'typy wydarzeń';
$lang['event_types_header'] = 'Typy wydarzeń';
$lang['event_types_add'] = 'Dodaj typ wydarzenia...';
$lang['event_types_count'] = 'Liczba typów wydarzeń:';


$lang['event_type_edit_title'] = 'edycja typu wydarzenia';
$lang['event_type_edit_add'] = 'Dodawanie typu wydarzenia';
$lang['event_type_edit_edit'] = 'Edycja typu wydarzenia:';
$lang['event_type_edit_name'] = 'Nazwa:';
$lang['event_type_edit_icon'] = 'Ikona:';

$lang['items_title'] = 'elementy kalendarza';
$lang['items_header'] = 'Elementy kalendarza';
$lang['items_type'] = 'Typ:';
$lang['items_add'] = 'Dodaj element kalendarza...';
$lang['items_count'] = 'Liczba elementów:';
$lang['items_filter_label'] = 'Wyświetl elementy typu:';
$lang['items_filter_all'] = 'Wszystkie';
$lang['items_linking_1'] = 'Możesz stworzyć bezpośredni link do pokazania wydarzeń wybranego elementu według wzoru:';
$lang['items_linking_2'] = 'ROK/MIESIĄC/ID ELEMENTU';
$lang['items_linking_3'] = 'W miejsce ROK i MIESIĄC możesz wpisac &quot;0&quot; aby wyświetlić rok i miesiąc dla aktualnej daty. ';

$lang['item_edit_title'] = 'edycja elementu kalendarza';
$lang['item_edit_add'] = 'Dodawanie elementu kalendarza typu:';
$lang['item_edit_edit'] = 'Edycja elementu kalendarza:';
$lang['item_edit_name'] = 'Nazwa:';
$lang['item_edit_icon'] = 'Ikona:';
$lang['item_edit_fields'] = 'Pola';
$lang['item_edit_field_type'] = 'Pole typu:';
$lang['item_edit_field_text'] = 'Tekst';
$lang['item_edit_field_link'] = 'Link';
$lang['item_edit_field_image'] = 'Zdjęcie';
$lang['item_edit_field_label'] = 'Etykieta:';
$lang['item_edit_field_value'] = 'Wartość:';
$lang['item_edit_field_link_value'] = 'Link:';
$lang['item_edit_field_link_text'] = 'Tekst linku:';
$lang['item_edit_field_image_value'] = 'Zdjęcie:';
$lang['item_edit_field_image_help'] = 'Dozwolony format pliku to JPG.';

$lang['item_types_title'] = 'typy elementów kalendarza';
$lang['item_types_header'] = 'Typy elementów kalendarza';
$lang['item_types_add'] = 'Dodaj typ elementu kalendarza...';
$lang['item_types_count'] = 'Liczba typów:';
$lang['item_types_order_help'] = 'Przesuwaj typy wydarzeń aby ustalić ich kolejność wyświetlania w kalendarzu.';

$lang['item_type_edit_title'] = 'edycja typu elementu kalendarza';
$lang['item_type_edit_add'] = 'Dodawanie typu elementu kalendarza';
$lang['item_type_edit_edit'] = 'Edycja typu elementu kalendarza:';
$lang['item_type_edit_name'] = 'Nazwa:';
$lang['item_type_edit_icons'] = 'Dozwolone ikony:';
$lang['item_type_edit_icons_help'] = 'Ikony które będzie można wybierać edytując szczegóły elementu kalendarza.';
$lang['item_type_edit_events'] = 'Typy wydarzeń:';
$lang['item_type_edit_events_help'] = 'Tylko wydarzenia zaznaczonych typów będzie można dodawać korzystając z tego typu elementu kalendarza.';
$lang['item_type_edit_events_no'] = 'Najpierw dodaj typy wydarzeń w aplikacji abyś mógł je przypisać do typów elementów kalendarza.';
$lang['item_type_edit_events_no_selected'] = 'Zaznacz przynajmniej jeden typ wydarzeń.';
$lang['item_type_edit_desc_header'] = 'Pola opisu wydarzeń';
$lang['item_type_edit_desc_help'] = 'Wyświetl pomoc odnośnie pól opisu wydarzeń';
$lang['item_type_edit_desc1_label'] = 'Etykieta pola opisu nr 1:';
$lang['item_type_edit_desc1_label_show'] = 'Pokaż etykietę pola opisu nr 1 przed jego wartością';
$lang['item_type_edit_desc2_label'] = 'Etykieta pola opisu nr 2:';
$lang['item_type_edit_desc2_label_show'] = 'Pokaż etykietę pola opisu nr 2 przed jego wartością';
$lang['item_type_edit_desc_label_show_help'] = 'Etykieta zostanie wyświetlona tylko gdy nie jest pusta.';
$lang['item_type_edit_descs_help'] = 'Etykieta jaka będzie wyświetlana nad polem podczas edycji wydarzeń.';
$lang['item_type_edit_desc1_type'] = 'Typ pola opisu nr 1:';
$lang['item_type_edit_desc2_type'] = 'Typ pola opisu nr 2:';
$lang['item_type_edit_desc_type_short'] = 'Krótkie pole tekstowe (maks. 60 znaków)';
$lang['item_type_edit_desc_type_long'] = 'Wielowierszowe pole tekstowe';
$lang['item_type_edit_desc2_disabled'] = 'Wyłacz pole opisu nr 2 w przeglądaniu i edycji wydarzeń';
$lang['item_type_edit_desc_show_how'] = 'Wyświetlanie treści pól opisu:';
$lang['item_type_edit_desc_show_separate'] = 'Jedno pod drugim';
$lang['item_type_edit_desc_show_asone'] = 'Połacz wartości jak w jedno pole';
$lang['item_type_edit_desc_show_type_help'] = 'Sposób w jaki będzie wyświetlana treść poł opisowych gdy użytkownik ma uprawnienia do obydwu.';


$lang['item_type_edit_fields'] = 'Pola elementu';
$lang['item_type_edit_fields_help'] = 'Wyświetl pomoc odnośnie położenia pól';
$lang['item_type_edit_fields_add'] = 'Dodaj...';
$lang['item_type_edit_field_text'] = 'Tekst';
$lang['item_type_edit_field_image'] = 'Zdjęcie';
$lang['item_type_edit_field_link'] = 'Link';
$lang['item_type_edit_field_type'] = 'Pole typu:';
$lang['item_type_edit_field_label'] = 'Etykieta:';
$lang['item_type_edit_field_label_show'] = 'Pokazuj etykietę';
$lang['item_type_edit_field_filtering'] = 'Zezwalaj na filtrowanie';
$lang['item_type_edit_field_filtering_help'] = 'Zezwalaj na filtrowanie elementów podczas przeglądania kalendarza według wartości tego pola.';
$lang['item_type_edit_field_size'] = 'Rozmiar zdjęcia:';
$lang['item_type_edit_field_size_s'] = 'Mały';
$lang['item_type_edit_field_size_m'] = 'Średni';
$lang['item_type_edit_field_size_l'] = 'Duży';
$lang['item_type_edit_field_position'] = 'Pozycja';
$lang['item_type_edit_field_up'] = 'Przesuń w górę';
$lang['item_type_edit_field_down'] = 'Przesuń w dół';


//MODAL field positions  
$lang['modal_fields_header'] = 'Pozycje pól';
$lang['modal_fields_1'] = 'Pozycja pola służy do układania pól według poniższego schematu.';
$lang['modal_fields_2'] = 'Na przykład gdy wybierzesz pozycję B dla jednego pola, a dla drugiego C to będą one wyświetlane obok siebie.';

//MODAL desc fields
$lang['modal_desc_fields_header'] = 'Pola opisu wydarzenia';
$lang['modal_desc_fields_1'] = 'Każde wydarzenie może mieć swój opis. Standardowo dostępne są dwa pola opisu. Możesz przyznac różne uprawnienia użytkownikom tak aby widzieli jeden opis, a nie widzieli drugiego i na odwrót.';
$lang['modal_desc_fields_2'] = 'Przykład ustawień:';
$lang['modal_desc_fields_li_1'] = 'pole nr 1 wykorzystaj na wpisywanie godziny wydarzenia, a pole nr 2 na szczegóły wydarzenia';
$lang['modal_desc_fields_li_2'] = 'nadaj uprawnienia użytkownikom niezalogowanym aby widzieli treść pola nr 1 (godziny wydarzenia) ale nie widzieli pola nr 2 (szczegółów wydarzenia)';
$lang['modal_desc_fields_li_3'] = 'użytkownikom zalogowanym nadaj uprawnienia aby widzieli treść obydwu pól';
$lang['modal_desc_fields_3'] = 'Ten sposób ustawień można użyć w kalendarzu do oznaczania rezerwacji auta, sali konferencyjnej lub podobnych. Niezalogowane osoby widzą że przedmiot jest zajęty w danych godzinach ale nie widzą szczegółów. Tylko uprawnione osoby zalogowane widzą szczegóły rezerwacji.';


//MODAL events editor
$lang['modal_events_edit_day_header'] = 'Edycja wydarzeń dnia:';
$lang['modal_events_edit_days_header'] = 'Dodawanie wydarzeń do liczby dni:';
$lang['modal_events_edit_none'] = 'Brak wydarzeń.';
//$lang['modal_events_edit_desc'] = 'Opis:';
$lang['modal_events_edit_desc_type_default_label'] = 'Opis (pole nr {0}):';
$lang['modal_events_edit_main'] = 'Główne wydarzenie';
$lang['modal_events_edit_order'] = 'Zmień kolejność';
$lang['modal_events_edit_edit'] = 'Edytuj';
$lang['modal_events_edit_del'] = 'Usuń';
$lang['modal_events_edit_choose'] = 'Wybierz typ wydarzenia...';
$lang['modal_events_edit_type'] = 'Typ wydarzenia:';
$lang['modal_events_edit_type_locked'] = 'Ten typ wydarzenia został wyłączony w tym typie elementu. Nie możesz zmienić typu tego wydarzenia.';
$lang['modal_events_edit_add'] = 'Dodaj wydarzenie...';
$lang['modal_events_edit_main_help'] = 'Porada: Główne wydarzenie to wydarzenie które będzie wyświetlane w komórce dnia kalendarza.';
$lang['modal_events_edit_add_help'] = 'Utworzone wydarzenia zostaną dodane do zaznaczonych wcześniej komórek.';


//CONFIRM MODAL 
$lang['confirm_delete_user_header'] = 'Usuwanie użytkownika';
$lang['confirm_delete_user'] = 'Czy chcesz na pewno usunąć użytkownika?';
$lang['confirm_delete_group_header'] = 'Usuwanie grupy';
$lang['confirm_delete_group'] = 'Czy chcesz na pewno usunąć grupę uprawnień?';
$lang['confirm_delete_event_type_header'] = 'Usuwanie typu wydarzenia';
$lang['confirm_delete_event_type_1'] = 'Czy chcesz na pewno usunąć typ wydarzenia?';
$lang['confirm_delete_event_type_2'] = 'Spowoduje to usunięcie wszystkich wydarzeń tego typu w kalendarzu oraz usunięcie wraz z wydarzeniami wszystkich  elementów kalendarza które w swoim typie używają tego typu wydarzenia jako jedyny do wyboru.';
$lang['confirm_delete_item_type_header'] = 'Usuwanie typu elementu kalendarza';
$lang['confirm_delete_item_type_1'] = 'Czy chcesz na pewno usunąć typ elementu kalendarza?';
$lang['confirm_delete_item_type_2'] = 'Spowoduje to usunięcie wszystkich wydarzeń tego typu elementów w kalendarzu.';
$lang['confirm_delete_item_header'] = 'Usuwanie elementu kalendarza';
$lang['confirm_delete_item_1'] = 'Czy chcesz na pewno usunąć element kalendarza?';
$lang['confirm_delete_item_2'] = 'Spowoduje to usunięcie wszystkich wydarzeń tego elementu w kalendarzu.';
$lang['confirm_delete_all_events_header'] = 'Usuwanie wszystkich wydarzeń';
$lang['confirm_delete_all_events'] = 'Czy chcesz na pewno usunąć wszystkie wydarzenia w zaznaczonych komórkach?';


//icon selector and icons section names 
$lang['icon_selector_empty'] = 'Zaznaczaj ikony z listy aby je wybrać...';
$lang['icons_people'] = 'Ludzie';
$lang['icons_absence'] = 'Nieobecności';
$lang['icons_animals'] = 'Zwierzęta';
$lang['icons_arrows'] = 'Strzałki';
$lang['icons_multimedia'] = 'Multimedia';
$lang['icons_numbers'] = 'Liczby';
$lang['icons_other'] = 'Inne';
$lang['icons_reservation'] = 'Rezerwacja';
$lang['icons_vehicles'] = 'Pojazdy';


//UPLOADER responses
$lang['uploader_no_file'] = 'Brak pliku';
$lang['uploader_select'] = 'Wybierz plik...';
$lang['uploader_clear'] = 'Wyczyść';
$lang['uploader_ext_not_allowed'] = 'Ten typ rozszerzenia nie jest dozwolony:';
$lang['uploader_error'] = 'Wystąpił błąd podczas ładowania pliku:';


//SELECTION PANEL
$lang['selection_days'] = 'Zaznaczonych dni:';
$lang['selection_multi_types'] = 'Zaznaczyłeś komórki dni w różnych typach elementów kalendarza, wspólne dodawanie wydarzeń jest niemożliwe.';
$lang['selection_add'] = 'Dodaj wydarzenia...';
$lang['selection_remove'] = 'Usuń wydarzenia';


//AJAX responses
$lang['admin_ajax_events_saved'] = 'Wydarzenia zostały zapisane';
$lang['admin_ajax_events_deleted'] = 'Wydarzenia zostały usunięte';
$lang['admin_ajax_password_changed'] = 'Hasło zostało zmienione';
$lang['admin_ajax_settings_saved'] = 'Ustawienia zostały zapisane';
$lang['admin_ajax_user_deleted'] = 'Użytkownik został usunięty';
$lang['admin_ajax_user_saved'] = 'Użytkownik zapisany';
$lang['admin_ajax_group_deleted'] = 'Grupa została usunięta';
$lang['admin_ajax_group_saved'] = 'Grupa została zapisana';
$lang['admin_ajax_user_perms_saved'] = 'Uprawnienia użytkownika zostały zapisane';
$lang['admin_ajax_event_type_saved'] = 'Typ wydarzenia został zapisany';
$lang['admin_ajax_event_type_deleted'] = 'Typ wydarzenia został usunięty';
$lang['admin_ajax_item_types_order'] = 'Kolejność zapisana';
$lang['admin_ajax_item_type_deleted'] = 'Typ elementu kalendarza został usunięty';
$lang['admin_ajax_item_type_saved'] = 'Typ elementu kalendarza został zapisany';
$lang['admin_ajax_item_deleted'] = 'Element kalendarza został usunięty';
$lang['admin_ajax_item_saved'] = 'Element kalendarza został zapisany';



//AJAX ERRORS
$lang['ajax_error_forbidden'] = 'Brak dostępu. Proszę odświeżyć stronę';
$lang['ajax_error_wrong_params'] = 'Błąd: Przekazano złe parametry';
$lang['ajax_error_call_error'] = 'Błąd żadania Ajax: ';
$lang['ajax_error_saving_data'] = 'Błąd zapisywania danych';
$lang['ajax_error_resource_not_found'] = 'Błąd: Nie znaleziono zasobu';


$lang['delete'] = 'Usuń';
$lang['ok'] = 'Ok';
$lang['cancel'] = 'Anuluj';
$lang['no_results'] = 'Brak wyników';


$lang['no_changes'] = 'Brak zmian do zapisania';
$lang['save_changes'] = 'Zapisz zmiany';
$lang['save_back_changes'] = 'Zapisz zmiany i wróć';
$lang['unsaved'] = 'Istnieją niezapisane zmiany. Czy na pewno chcesz opuścić stronę?';

$lang['version_check'] = 'Dostępna jest nowa wersja aplikacji.<br/><a href="https://flexphperia.net/yc" target="_blank">Kliknij tutaj żeby zobaczyć szczegóły.</a>';


//errors
$lang['error_404'] = 'Błąd 404 - Strona nie znaleziona, sprawdź adres URL';
$lang['error_403'] = 'Błąd 403 - Nie masz uprawnień aby oglądać tę stronę';
$lang['error_iframe'] = 'Ta aplikacja nie może być wyświetlana w ramce. Kliknij tutaj aby otworzyć na nowej karcie.';
$lang['old_browser'] = 'Ta przeglądarka nie jest obsługiwana. Skorzystaj z nowoczesnej przeglądarki jak Chrome, Firefox lub Opera.';