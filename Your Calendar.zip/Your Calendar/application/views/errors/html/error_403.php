
<div class="lead text-center">
    <?php echo lang('error_403'); ?>
</div>