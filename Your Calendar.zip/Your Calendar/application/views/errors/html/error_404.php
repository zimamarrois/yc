
<div class="lead text-center">
    <?php echo lang('error_404'); ?>
</div>