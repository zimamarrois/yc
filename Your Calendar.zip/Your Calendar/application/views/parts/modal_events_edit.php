<div id="modalEventsEdit" class="modal fade " tabindex="-1" role="dialog">
    <div class="modal-dialog " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" data-state="edit"><?php echo lang('modal_events_edit_day_header') ?><span class="ml-1 text-nowrap" data-date></span></h5>
                <h5 class="modal-title" data-state="add"><?php echo lang('modal_events_edit_days_header') ?><span class="ml-1" data-num></span></h5>
            </div>
            <div class="modal-body">
                <div class="events-list"></div><!--		

                --><p class="empty"><?php echo lang('modal_events_edit_none') ?></p>

                <form class="d-none" data-form-template>
                    
                    <div class="form-group">
                        <label for="meeTyp"><?php echo lang('modal_events_edit_type') ?></label>
                        <select id="meeTyp" class="form-control" 
                                title="<?php echo lang('modal_events_edit_choose') ?>" 
                                data-no-results="<?php echo lang('no_results') ?>"
                                name="event_type"
                                >
                        </select>
                        <div class="alert alert-warning d-none small mb-0" role="alert">
                            <?php echo lang('modal_events_edit_type_locked') ?>
                        </div>
                    </div>
                    
                    <div class="form-group" data-desc-type="long">
                        <label data-default="<?php echo lang('modal_events_edit_desc_type_default_label') ?>"></label>
                        <textarea class="form-control" rows="3" maxlength="480"></textarea>
                    </div>
                    
                    <div class="form-group" data-desc-type="short">
                        <label data-default="<?php echo lang('modal_events_edit_desc_type_default_label') ?>"></label>
                        <input type="text" name="name" class="form-control" maxlength="60" />
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-sm mt-2 mb-2"><?php echo lang('ok') ?></button>
                </form>	


                <div class="event-row d-none" data-row-template >
                    <div class="controls p-1">
                        <div class="btn-group btn-group-sm" role="group" >
                            <button type="button" class="btn btn-light btn-sm"
                                    title="<?php echo lang('modal_events_edit_order') ?>" data-move><?php ico('drag', 'small') ?></button><!--
                            --><button type="button" class="btn btn-light btn-sm" 
                                       title="<?php echo lang('modal_events_edit_edit') ?>" data-edit ><?php ico('edit', 'small') ?></button><!--
                            --><button type="button" class="btn btn-light btn-sm" 
                                       title="<?php echo lang('modal_events_edit_del') ?>" data-delete><?php ico('waste', 'small') ?></button>
                        </div>
                        <div class="custom-control custom-switch ml-2">
                            <input type="checkbox" class="custom-control-input" id="" name="is_main" >
                            <label class="custom-control-label" for=""><?php echo lang('modal_events_edit_main') ?></label>
                        </div>
                    </div>
                    <div class="event-wrap pt-1 pr-2 pl-2 pb-1">

                    </div>
                    <input type="hidden" name="id"  />
                    <input type="hidden" name="type-id"  />
                </div>


                <div class="tips text-muted">
                    <p><small><?php echo lang('modal_events_edit_main_help'); ?></small></p>
                    <p data-state="add" ><small ><?php echo lang('modal_events_edit_add_help'); ?></small></p>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success mr-auto btn-sm" data-add><?php echo lang('modal_events_edit_add'); ?></button>
                <button type="button" class="btn btn-primary btn-sm"><?php echo lang('save_changes'); ?></button>
                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal"><?php echo lang('cancel'); ?></button>
            </div>
        </div>
    </div>
</div>