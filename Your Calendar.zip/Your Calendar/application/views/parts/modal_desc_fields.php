<div id="modalDescFields" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" ><?php echo lang('modal_desc_fields_header') ?></h5>
                <button type="button" class="close" data-dismiss="modal" >
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p><?php echo lang('modal_desc_fields_1') ?></p>
                <?php echo lang('modal_desc_fields_2') ?>
                <ul class="pl-4">
                    <li><?php echo lang('modal_desc_fields_li_1') ?></li>
                    <li><?php echo lang('modal_desc_fields_li_2') ?></li>
                    <li><?php echo lang('modal_desc_fields_li_3') ?></li>
                </ul>
                <p><?php echo lang('modal_desc_fields_3') ?></p>
            </div>
        </div>
    </div>
</div>
