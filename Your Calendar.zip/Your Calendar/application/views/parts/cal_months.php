<?php 
 foreach ($cal_data as $data)
 {
     $cal_renderer->calendar(
             $data['year'], 
             $data['month'], 
             $data['events'], 
             $items, 
             false, 
             $this->settings_vo->show_empty_rows, 
             $item_to_show 
    );
 }