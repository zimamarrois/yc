<div class="uploader">
    <div class="preview">
        <img src="" class="d-none" />
        <div class="no-image"><?php echo lang('uploader_no_file'); ?></div>
    </div><br/>
    <button type="button" class="btn btn-secondary btn-sm" data-upload><?php echo lang('uploader_select'); ?></button><?php if (@$clear_button): ?>
<button type="button" class="btn btn-secondary btn-sm ml-1" data-clear><?php echo lang('uploader_clear'); ?></button>
    <?php endif; ?>
    <div class="progress d-none">
        <div class="progress-bar bg-success" role="progressbar">0%</div>
    </div>
    <div class="d-none" data-wrong-ext>
        <small class="text-danger" ><?php echo lang('uploader_ext_not_allowed'); ?><span class="mx-1" data-ext></span></small>
    </div>	
    <div class="d-none" data-error>
        <small class="text-danger" ><?php echo lang('uploader_error'); ?><span class="ml-1" data-status></span></small>
    </div>
    <input type="hidden" name="<?php echo $field_name ?>" <?php echo ($required ? 'data-val-required' : '') ?> data-val-delegate-sibling=".preview"  />
</div>