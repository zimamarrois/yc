<!--start=".item-list"-->
<div class="item-list">
    <div class="card-subtitle text-muted small text-right">
        <?php echo $list_data['subtitle'] ?>
        <span class="ml-1" data-count><?php echo $list_data['count'] ?></span>
    </div>
    <div class="list">
        <?php foreach( $list_data['items'] as $item): ?>
            <div class="item"
                    <?php if (@$item['data']): ?>
                        <?php foreach( $item['data'] as $data_name => $val ): ?>
                                data-<?php echo $data_name ?>="<?php echo $val ?>" 
                        <?php endforeach; ?>
                    <?php endif; ?>
            >
            <div class="column left">
                <a href="<?php echo $item['link'] ?>" >
                <?php if(@$item['icon']): ?>
                        <?php echo get_ico($item['icon']); ?><!--
                --><?php endif; ?><!--
                --><span><?php echo $item['text'] ?></span>
                </a>

                <?php if (@$item['details']): ?>
                        <?php foreach( $item['details'] as $detail): ?>
                                <p class="small text-muted"><?php echo $detail ?></p>
                        <?php endforeach; ?>
                <?php endif; ?>
            </div>	
            <div class="column right">
                <?php if (@$item['delete_button']): ?>	
                    <button type="button" class="btn btn-primary btn-sm" data-delete ><?php echo lang('delete'); ?></button>
                <?php endif; ?>
                <?php if (@$item['order_button']): ?>	
                    <button type="button" class="btn btn-light btn-sm" data-move ><?php ico('drag', 'small') ?></button>
                <?php endif; ?>
            </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<!--end=".item-list"-->