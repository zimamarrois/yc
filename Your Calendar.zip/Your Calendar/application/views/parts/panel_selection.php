<div id="selectionPanel" class="card border-secondary d-none"  >
  <div class="card-header">
      <?php echo lang('selection_days'); ?><span class="ml-1" data-day-count></span>
	<button type="button" class="close text-body" >
	  <span aria-hidden="true">&times;</span>
	</button>
  </div>
  <div class="card-body">
    <p class="card-text d-none text-info" data-warning><small><?php echo lang('selection_multi_types'); ?></small></p>
	<button type="button" class="btn btn-primary btn-sm btn-block" data-add ><?php echo lang('selection_add'); ?></button>
	<button type="button" class="btn btn-primary btn-sm btn-block" data-delete><?php echo lang('selection_remove'); ?></button>
  </div>
</div>