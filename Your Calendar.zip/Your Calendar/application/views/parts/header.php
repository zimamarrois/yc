<!--
 This file is part of Your Calendar app. It requires license to use.
 Copyright (c) 2020 flexphperia.net All rights reserved.

--><!DOCTYPE html>
<html lang="<?php echo lang('html_lang'); ?>">
    <head>
        <title><?php echo html_escape($this->settings_vo->title); ?> - <?php echo html_escape($title); ?></title>
        <meta charset="utf-8">
        <meta name="google" content="notranslate">
        <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
        <meta name="author" content="flexphperia.net" />

        <?php
        if (ENVIRONMENT == 'development')
        {
            require_once FCPATH . 'public/css/dev/development.php';
        }
        else
        {
            ?>
            <link rel="stylesheet" href="<?php echo base_url('public/css/style-min.css?v' . $this->config->item('yc_version')); ?>" />
            <?php
        }
        ?>

        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo base_url('public/img/favicon-144x144.png'); ?>" />
        <link rel="apple-touch-icon-precomposed" sizes="152x152" href="<?php echo base_url('public/img/favicon-152x152.png'); ?>" />
        <link rel="icon" type="image/png" href="<?php echo base_url('public/img/favicon-32x32.png'); ?>" sizes="32x32" />
        <link rel="icon" type="image/png" href="<?php echo base_url('public/img/favicon-16x16.png'); ?>" sizes="16x16" />

        <?php

        //render registered styles
        $this->controller->render_styles();
        ?>

        <script>
            window.YourCalendar = {};
            function yc_data(key, val) {
                YourCalendar[key] = val;
            }
        </script>

    </head>
    
    <?php 
    
        $hide_header = !$this->aauth->is_loggedin() && $this->settings_vo->hide_header;
    ?>
    
    <body class="<?php echo ($hide_header ? 'hide-header' : '') ?>">
        <?php
        //load svg definitions
        $this->load->view('parts/svg_icons_app.php'); //used by app
        
        $this->load->view('parts/svg_icons.php');
        ?>

    <?php if (!$hide_header): ?>
        <nav id="header" class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
            <div class="container">
                <a class="navbar-brand" href="<?php echo site_url(); ?>">
                    
                  <img src="<?php echo base_url(config_item('yc_img_generator_url')); ?>?dir=uploads&width=340&filename=<?php echo $this->settings_vo->logo; ?>" />
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".dual-collapse2">
                    <span class="navbar-toggler-icon"></span>
                </button>

                        
            <?php 
                //collect what menu to show
                $manage = array(
                    'items' => count(filter_item_type_add_delete($this->item_types_model->get(null))) > 0 || //item types that user allowed to add
                                count(filter_item_edit($this->items_model->get())) > 0,
                    'item_types' => can(array('add_delete_item_types', 'edit_item_types'), 'or'),
                    'event_types' => can(array('add_delete_event_types', 'edit_event_types'), 'or'),
                    'users' => can(array('add_delete_users', 'edit_users'), 'or'),
                    'permissions' => can('edit_permissions'),
                    'settings' => can('edit_settings'),
                );

                $manage['any'] = in_array(true, array_values($manage), true);

                $can_edit = count(filter_item_events_edit($this->items_model->get())) > 0;
            ?>
                  
                <div class="navbar-collapse collapse dual-collapse2">
                    <ul class="navbar-nav ml-auto">
                        
        <?php if ($can_edit || $manage['any']):  ?>   
        <li class="nav-item mr-md-3">
            <a class="nav-link <?php menu_active_class('browse') ?>" href="<?php echo site_url() ?>"><?php ico('calendar') ?><span><?php echo lang('nav_browse') ?></span></a>
        </li>
        <?php endif; ?>
       
        <?php if ($can_edit):  ?>       
            <li class="nav-item dropdown mr-md-3">
                <div class="btn-group d-flex flex-wrap ">
                    <a class="nav-link pr-2 pr-md-0 <?php menu_active_class('edit') ?>" href="<?php echo site_url($this->settings_vo->edit_one_only ? 'edit-select' : 'edit') ?>" role="button"><?php ico('calendar-plus') ?><span><?php echo lang('nav_edit') ?></span></a>
                    <?php if (!$this->settings_vo->edit_one_only): ?>
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></a>
                        <div class="w-100 d-md-none"></div> <!-- breaker -->
                        <div class="dropdown-menu flex-grow-1">
                            <a class="dropdown-item" href="<?php echo site_url('edit-select') ?>"><?php echo lang('nav_edit_selected') ?></a>
                        </div>
                    <?php endif; ?>
                </div>
            </li>
        <?php endif; ?>
                        
        <?php if ($manage['any']):  ?>
        <li class="nav-item dropdown mr-md-3">
            <a class="nav-link dropdown-toggle <?php menu_active_class('manage') ?>" href="#"  role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <?php ico('settings') ?><span><?php echo lang('nav_manage') ?></span>
            </a>
            <div class="dropdown-menu dropdown-menu-right"  >
                <?php if ($manage['items']):  ?>
                    <a class="dropdown-item" href="<?php echo site_url('items') ?>"><?php echo lang('nav_items') ?></a>
                <?php endif; ?>
                <?php if ($manage['item_types']):  ?>
                    <a class="dropdown-item" href="<?php echo site_url('item_types') ?>"><?php echo lang('nav_item_types') ?></a>
                <?php endif; ?>
                <?php if ($manage['event_types']):  ?>
                    <a class="dropdown-item" href="<?php echo site_url('event_types') ?>"><?php echo lang('nav_event_types') ?></a>
                <?php endif; ?>
                <?php if ($manage['users']):  ?>
                    <a class="dropdown-item" href="<?php echo site_url('users') ?>"><?php echo lang('nav_users') ?></a>
                <?php endif; ?>
                <?php if ($manage['permissions']):  ?>
                    <a class="dropdown-item" href="<?php echo site_url('permissions/users') ?>"><?php echo lang('nav_user_perms') ?></a>
                    <a class="dropdown-item" href="<?php echo site_url('permissions/groups') ?>"><?php echo lang('nav_groups') ?></a>
                <?php endif; ?>
                <?php if ($manage['settings']):  ?>
                    <a class="dropdown-item" href="<?php echo site_url('settings') ?>"><?php echo lang('nav_settings') ?></a>
                <?php endif; ?>
            </div>
        </li>
        <?php endif; ?>
                    </ul>
                </div>

                <div class="navbar-collapse collapse dual-collapse2">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item dropdown  ">
                            <?php if ($this->aauth->is_loggedin()): ?>
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <?php ico('user') ?><span><?php echo $this->session->username ?></span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" >
                                    <a class="dropdown-item" href="<?php echo site_url('users/change_password') ?>"><?php echo lang('nav_pass') ?></a>
                                    <a class="dropdown-item" href="<?php echo site_url('logout') ?>"><?php echo lang('nav_logout') ?></a>
                                </div>
                            <?php else: ?>
                                <a class="nav-link " href="<?php echo site_url('login') ?>" role="button" >
                                    <?php if (!$this->settings_vo->hide_login_button): ?>
                                        <?php ico('lock') ?><span><?php echo lang('nav_login') ?></span>
                                    <?php endif; ?>
                                </a>
                            <?php endif; ?>


                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    <?php endif; ?>

        <div id="container">