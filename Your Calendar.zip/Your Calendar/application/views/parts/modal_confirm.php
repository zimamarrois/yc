<div id="modalConfirm" class="modal fade" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" data-state="delete-user"><?php echo lang('confirm_delete_user_header') ?></h5>
        <h5 class="modal-title" data-state="delete-group"><?php echo lang('confirm_delete_group_header') ?></h5>
        <h5 class="modal-title" data-state="delete-event-type"><?php echo lang('confirm_delete_event_type_header') ?></h5>
        <h5 class="modal-title" data-state="delete-item-type"><?php echo lang('confirm_delete_item_type_header') ?></h5>
        <h5 class="modal-title" data-state="delete-item"><?php echo lang('confirm_delete_item_header') ?></h5>
        <h5 class="modal-title" data-state="delete-all-events"><?php echo lang('confirm_delete_all_events_header') ?></h5>
      </div>
      <div class="modal-body">
		<p data-state="delete-user"><?php echo lang('confirm_delete_user') ?></p>
		<p data-state="delete-group"><?php echo lang('confirm_delete_group') ?></p>
		<p data-state="delete-event-type"><?php echo lang('confirm_delete_event_type_1') ?></p>
		<p data-state="delete-event-type" class="text-danger"><?php echo lang('confirm_delete_event_type_2') ?></p>
		<p data-state="delete-item-type" ><?php echo lang('confirm_delete_item_type_1') ?></p>
		<p data-state="delete-item-type" class="text-danger"><?php echo lang('confirm_delete_item_type_2') ?></p>
		<p data-state="delete-item" ><?php echo lang('confirm_delete_item_1') ?></p>
		<p data-state="delete-item" class="text-danger"><?php echo lang('confirm_delete_item_2') ?></p>
		<p data-state="delete-all-events"><?php echo lang('confirm_delete_all_events') ?></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary btn-sm"><?php echo lang('ok') ?></button>
        <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal"><?php echo lang('cancel') ?></button>
      </div>
    </div>
  </div>
</div>
