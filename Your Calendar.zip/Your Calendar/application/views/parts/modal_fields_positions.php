<div id="modalFieldsPositions" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog " role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" ><?php echo lang('modal_fields_header') ?></h5>
                <button type="button" class="close" data-dismiss="modal" >
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p class="mb-0"><?php echo lang('modal_fields_1') ?></p>
                <p><?php echo lang('modal_fields_2') ?></p>

                <div class="positions">
                    <div class="a">A</div>
                    <div class="b">B</div><!--
                    --><div class="c">C</div>
                    <div class="d">D</div>
                </div>

            </div>

        </div>
    </div>
</div>
