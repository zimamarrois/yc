<div id="monthSelector" data-month="<?php echo $month ?>" >
	<div class="controls d-flex justify-content-center align-items-center">
		<button type="button" class="btn btn-light btn-sm" data-prev>&laquo;</button>
			<div class="year text-center mx-4"><?php echo $year ?></div>
		<button type="button" class="btn btn-light btn-sm" data-next>&raquo;</button>
	</div>
	
	<div class="months mt-2" >
		<?php for ($i=1; $i<=12; $i++): ?>
                    <a class="dropdown-item px-2" href="#" data-num="<?php echo $i; ?>"><?php echo get_month_name($i); ?></a>
		<?php endfor; ?>
	</div>

</div>