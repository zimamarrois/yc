<?php
    $prefix = $this->path == 'main/edit' ? 'edit/' : '';
    
    $suffix = '';
    if ($prefix == 'edit/' && $item_id != 0)
    {
        $suffix = '/' . $item_id;
    }
?>
<div class="cal-navigation">

    <?php if(count($cal_data) == 1): ?>
        <div class="controls">
            <a href="<?php echo site_url($prefix.$year_prev .'/' . $month_prev.$suffix) ?>" class="btn btn-light btn-sm" >
                <span class="mr-2">&laquo;</span><?php echo lang('cal_nav_prev') ?>
            </a><!--
            --><a href="<?php echo site_url($prefix.$year_next .'/' . $month_next.$suffix) ?>" class="btn btn-light btn-sm" >
                <?php echo lang('cal_nav_next') ?><span class="ml-2">&raquo;</span>
            </a><!--
            --><button type="button" class="btn btn-light btn-sm" data-select-date
                       ><?php ico('date-span', 'small') ?><span><?php echo lang('cal_nav_select') ?></span>
            </button>
        </div>
    
    <?php else: ?>
    
    
        <div class="controls">
            <h5><?php echo lang('cal_nav_header'); ?></h5> 
            <div class="btn-toolbar month-controls" role="toolbar" >
                <div class="btn-group mr-1 btn-group-sm" role="group" >
                    <a href="<?php echo site_url($prefix.$year_prev .'/' . $month_prev.$suffix) ?>" class="btn btn-light btn-sm" >
                        &laquo;
                    </a>
                </div>
                <div class="btn-group  mr-1 btn-group-sm " role="group" >
                    <?php foreach ($cal_data as $month_data): ?>
                        <button type="button" class="btn btn-light" data-year="<?php echo $month_data['year'] ?>" data-month="<?php echo $month_data['month'] ?>">
                            <?php echo get_month_name($month_data['month']) . ' ' . $month_data['year'] ?>
                        </button>
                    <?php endforeach; ?>
                </div>
                <div class="btn-group btn-group-sm" role="group" >
                    <a href="<?php echo site_url($prefix.$year_next .'/' . $month_next.$suffix) ?>" class="btn btn-light btn-sm" >
                        &raquo;
                    </a>
                </div>	 
            </div>

            <button type="button" class="btn btn-light btn-sm" data-select-date><?php ico('date-span', 'small') ?><span>Wybierz...</span></button>
        </div>
    
    <?php endif; ?>
</div>
