<div class="icon-selector">
    <div class="selected-list">
        <div class="empty d-none"><?php echo lang('icon_selector_empty') ?></div>
    </div>
    <div class="icon-list">
        <?php if ( isset($icons) ): ?>
            <?php foreach($icons as $icon): ?>
                <a href="<?php echo $icon ?>" ><?php ico($icon) ?></a>
            <?php endforeach; ?>
        <?php else: //no icons passed get all icons that exists ?>
            <?php 
            
                $icons_order = config_item('icons_order');
                $icons = config_item('icons');
                
                foreach($icons_order as $section_name): 
            
                ?>
                <div class="header"><?php echo lang($section_name) ?></div>
                    <?php foreach($icons[$section_name] as $icon): ?>
                        <a href="<?php echo $icon ?>" ><?php ico($icon) ?></a>
                    <?php endforeach; ?>
            <?php endforeach; ?>
        <?php endif; ?>
        
    </div>
    <input type="hidden" name="<?php echo $field_name ?>"  <?php echo $data_attrs ?> />
</div>