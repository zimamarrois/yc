<?php foreach ($sections as $section): ?>
    <div class="section permissions">
        <h5>
            <?php echo $section['name'] ?>
            <?php if (@$section['tip']): ?>
                <small class="form-text text-muted"><?php echo $section['tip'] ?></small>
            <?php endif; ?>
        </h5>

        <?php foreach ($section['items'] as $item): $rand = mt_rand(); ?>
        
            <?php if (@$item['is_complex']): ?>
            <div class="form-group"> 
                <label class="mb-0"><?php echo $item['label'] ?></label>
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" 
                           id="e-<?php echo $rand ?>"
                           class="custom-control-input"
                           name="perms[<?php echo $item['perm_prefix'] ?>_events_browse_id_<?php echo $item['name'] ?>]"
                           data-dependent-id="<?php echo @$item['dependend_id'] ?>" >
                    <label class="custom-control-label" for="e-<?php echo $rand ?>" ><?php echo lang('perm_events_browse'); ?></label>
                    <small class="inherited-text form-text text-muted mt-0"><?php echo lang('perm_inherited'); ?></small>
                </div>	
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" 
                           id="e-<?php echo $rand + 1 ?>"
                           class="custom-control-input "
                           name="perms[<?php echo $item['perm_prefix'] ?>_events_desc1_id_<?php echo $item['name'] ?>]"
                           data-dependent-id="<?php echo @$item['dependend_id'] ?>" >
                    <label class="custom-control-label" for="e-<?php echo $rand + 1 ?>" ><?php echo lang('perm_events_desc1'); ?></label>
                    <small class="inherited-text form-text text-muted mt-0"><?php echo lang('perm_inherited'); ?></small>
                </div>	
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" 
                           id="e-<?php echo $rand + 2 ?>"
                           class="custom-control-input "
                           name="perms[<?php echo $item['perm_prefix'] ?>_events_desc2_id_<?php echo $item['name'] ?>]"
                           data-dependent-id="<?php echo @$item['dependend_id'] ?>" >
                    <label class="custom-control-label" for="e-<?php echo $rand + 2 ?>"><?php echo lang('perm_events_desc2'); ?></label>
                    <small class="inherited-text form-text text-muted mt-0"><?php echo lang('perm_inherited'); ?></small>
                </div>	
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" 
                           id="e-<?php echo $rand + 4 ?>"
                           class="custom-control-input "
                           name="perms[<?php echo $item['perm_prefix'] ?>_events_edit_id_<?php echo $item['name'] ?>]"
                           data-dependent-id="<?php echo @$item['dependend_id'] ?>" >
                    <label class="custom-control-label" for="e-<?php echo $rand + 4 ?>"><?php echo lang('perm_events_edit'); ?></label>
                    <small class="inherited-text form-text text-muted mt-0"><?php echo lang('perm_inherited'); ?></small>
                </div>	
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" 
                           id="e-<?php echo $rand + 5 ?>"
                           class="custom-control-input "
                           name="perms[<?php echo $item['perm_prefix'] ?>_edit_id_<?php echo $item['name'] ?>]"
                           data-dependent-id="<?php echo @$item['dependend_id'] ?>" >
                    <label class="custom-control-label" for="e-<?php echo $rand + 5 ?>"><?php echo lang('perm_edit'); ?></label>
                    <small class="inherited-text form-text text-muted mt-0"><?php echo lang('perm_inherited'); ?></small>
                </div>	
                <?php if(@$item['has_add']): ?>
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" 
                           id="e-<?php echo $rand + 6 ?>"
                           class="custom-control-input "
                           name="perms[<?php echo $item['perm_prefix'] ?>_add_delete_id_<?php echo $item['name'] ?>]"
                            >
                    <label class="custom-control-label" for="e-<?php echo $rand + 6 ?>"><?php echo lang('perm_add'); ?></label>
                    <small class="inherited-text form-text text-muted mt-0"><?php echo lang('perm_inherited'); ?></small>
                </div>	
                <?php endif; ?>

            </div>
            <?php else: ?>
            <div class="custom-control custom-checkbox">
                <input type="checkbox" 
                       class="custom-control-input "
                       id="e-<?php echo $rand ?>" 
                       name="perms[<?php echo $item['name'] ?>]" 
                       data-dependent-id="<?php echo @$item['dependend_id'] ?>" >

                <label class="custom-control-label" for="e-<?php echo $rand ?>"><?php echo $item['label'] ?></label>
                <small class="inherited-text form-text text-muted mt-0"><?php echo lang('perm_inherited'); ?></small>
            </div>	
            <?php endif; ?>
        <?php endforeach; ?>

    </div>
<?php endforeach; ?>