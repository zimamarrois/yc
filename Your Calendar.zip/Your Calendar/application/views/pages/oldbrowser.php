<div class="page text-danger text-center">
<?php echo lang('old_browser'); ?>
</div>