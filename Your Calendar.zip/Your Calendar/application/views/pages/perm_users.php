<div class="page page-perm-users fade">
    <div class="panel card">
        <div class="card-header">
            <?php echo lang('perm_users_header'); ?>
        </div>
        <div class="card-body">
            <?php $this->load->view('parts/item_list'); ?>
        </div>
    </div>
</div>


