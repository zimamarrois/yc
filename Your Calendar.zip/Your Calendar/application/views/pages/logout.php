<div class="page page-logout">
    <div  class="text-center">
        <h4><?php echo lang('logout_header'); ?></h4>
        <a href="<?php echo site_url('login'); ?>"> <?php echo lang('logout_login_link'); ?></a>
    </div>
</div>