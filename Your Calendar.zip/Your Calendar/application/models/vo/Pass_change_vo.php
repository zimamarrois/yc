<?php
/**
 * @author flexphperia
 *
 */
class Pass_change_vo extends Vo_base{

    public $old_password;

    public $new_password1;

    public $new_password2;
    
}